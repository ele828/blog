	var __wxAppData = __wxAppData || {}; 	var __wxRoute = __wxRoute || ""; 	var __wxRouteBegin = __wxRouteBegin || ""; 	var __wxAppCode__ = __wxAppCode__ || {};	var global = global || {};	var __WXML_GLOBAL__=__WXML_GLOBAL__ || {};	var __wxAppCurrentFile__=__wxAppCurrentFile__||""; 	var Component = Component || function(){};	var definePlugin = definePlugin || function(){};	var requirePlugin = requirePlugin || function(){};	var Behavior = Behavior || function(){};	var __vd_version_info__ = __vd_version_info__ || {};
	/*v0.5vv_20190312_syb_scopedata*/global.__wcc_version__='v0.5vv_20190312_syb_scopedata';global.__wcc_version_info__={"customComponents":true,"fixZeroRpx":true,"propValueDeepCopy":false};
var $gwxc
var $gaic={}
$gwx=function(path,global){
if(typeof global === 'undefined') global={};if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
function _(a,b){if(typeof(b)!='undefined')a.children.push(b);}
function _v(k){if(typeof(k)!='undefined')return {tag:'virtual','wxKey':k,children:[]};return {tag:'virtual',children:[]};}
function _n(tag){$gwxc++;if($gwxc>=16000){throw 'Dom limit exceeded, please check if there\'s any mistake you\'ve made.'};return {tag:'wx-'+tag,attr:{},children:[],n:[],raw:{},generics:{}}}
function _p(a,b){b&&a.properities.push(b);}
function _s(scope,env,key){return typeof(scope[key])!='undefined'?scope[key]:env[key]}
function _wp(m){console.warn("WXMLRT_$gwx:"+m)}
function _wl(tname,prefix){_wp(prefix+':-1:-1:-1: Template `' + tname + '` is being called recursively, will be stop.')}
$gwn=console.warn;
$gwl=console.log;
function $gwh()
{
function x()
{
}
x.prototype = 
{
hn: function( obj, all )
{
if( typeof(obj) == 'object' )
{
var cnt=0;
var any1=false,any2=false;
for(var x in obj)
{
any1=any1|x==='__value__';
any2=any2|x==='__wxspec__';
cnt++;
if(cnt>2)break;
}
return cnt == 2 && any1 && any2 && ( all || obj.__wxspec__ !== 'm' || this.hn(obj.__value__) === 'h' ) ? "h" : "n";
}
return "n";
},
nh: function( obj, special )
{
return { __value__: obj, __wxspec__: special ? special : true }
},
rv: function( obj )
{
return this.hn(obj,true)==='n'?obj:this.rv(obj.__value__);
},
hm: function( obj )
{
if( typeof(obj) == 'object' )
{
var cnt=0;
var any1=false,any2=false;
for(var x in obj)
{
any1=any1|x==='__value__';
any2=any2|x==='__wxspec__';
cnt++;
if(cnt>2)break;
}
return cnt == 2 && any1 && any2 && (obj.__wxspec__ === 'm' || this.hm(obj.__value__) );
}
return false;
}
}
return new x;
}
wh=$gwh();
function $gstack(s){
var tmp=s.split('\n '+' '+' '+' ');
for(var i=0;i<tmp.length;++i){
if(0==i) continue;
if(")"===tmp[i][tmp[i].length-1])
tmp[i]=tmp[i].replace(/\s\(.*\)$/,"");
else
tmp[i]="at anonymous function";
}
return tmp.join('\n '+' '+' '+' ');
}
function $gwrt( should_pass_type_info )
{
function ArithmeticEv( ops, e, s, g, o )
{
var _f = false;
var rop = ops[0][1];
var _a,_b,_c,_d, _aa, _bb;
switch( rop )
{
case '?:':
_a = rev( ops[1], e, s, g, o, _f );
_c = should_pass_type_info && ( wh.hn(_a) === 'h' );
_d = wh.rv( _a ) ? rev( ops[2], e, s, g, o, _f ) : rev( ops[3], e, s, g, o, _f );
_d = _c && wh.hn( _d ) === 'n' ? wh.nh( _d, 'c' ) : _d;
return _d;
break;
case '&&':
_a = rev( ops[1], e, s, g, o, _f );
_c = should_pass_type_info && ( wh.hn(_a) === 'h' );
_d = wh.rv( _a ) ? rev( ops[2], e, s, g, o, _f ) : wh.rv( _a );
_d = _c && wh.hn( _d ) === 'n' ? wh.nh( _d, 'c' ) : _d;
return _d;
break;
case '||':
_a = rev( ops[1], e, s, g, o, _f );
_c = should_pass_type_info && ( wh.hn(_a) === 'h' );
_d = wh.rv( _a ) ? wh.rv(_a) : rev( ops[2], e, s, g, o, _f );
_d = _c && wh.hn( _d ) === 'n' ? wh.nh( _d, 'c' ) : _d;
return _d;
break;
case '+':
case '*':
case '/':
case '%':
case '|':
case '^':
case '&':
case '===':
case '==':
case '!=':
case '!==':
case '>=':
case '<=':
case '>':
case '<':
case '<<':
case '>>':
_a = rev( ops[1], e, s, g, o, _f );
_b = rev( ops[2], e, s, g, o, _f );
_c = should_pass_type_info && (wh.hn( _a ) === 'h' || wh.hn( _b ) === 'h');
switch( rop )
{
case '+':
_d = wh.rv( _a ) + wh.rv( _b );
break;
case '*':
_d = wh.rv( _a ) * wh.rv( _b );
break;
case '/':
_d = wh.rv( _a ) / wh.rv( _b );
break;
case '%':
_d = wh.rv( _a ) % wh.rv( _b );
break;
case '|':
_d = wh.rv( _a ) | wh.rv( _b );
break;
case '^':
_d = wh.rv( _a ) ^ wh.rv( _b );
break;
case '&':
_d = wh.rv( _a ) & wh.rv( _b );
break;
case '===':
_d = wh.rv( _a ) === wh.rv( _b );
break;
case '==':
_d = wh.rv( _a ) == wh.rv( _b );
break;
case '!=':
_d = wh.rv( _a ) != wh.rv( _b );
break;
case '!==':
_d = wh.rv( _a ) !== wh.rv( _b );
break;
case '>=':
_d = wh.rv( _a ) >= wh.rv( _b );
break;
case '<=':
_d = wh.rv( _a ) <= wh.rv( _b );
break;
case '>':
_d = wh.rv( _a ) > wh.rv( _b );
break;
case '<':
_d = wh.rv( _a ) < wh.rv( _b );
break;
case '<<':
_d = wh.rv( _a ) << wh.rv( _b );
break;
case '>>':
_d = wh.rv( _a ) >> wh.rv( _b );
break;
default:
break;
}
return _c ? wh.nh( _d, "c" ) : _d;
break;
case '-':
_a = ops.length === 3 ? rev( ops[1], e, s, g, o, _f ) : 0;
_b = ops.length === 3 ? rev( ops[2], e, s, g, o, _f ) : rev( ops[1], e, s, g, o, _f );
_c = should_pass_type_info && (wh.hn( _a ) === 'h' || wh.hn( _b ) === 'h');
_d = _c ? wh.rv( _a ) - wh.rv( _b ) : _a - _b;
return _c ? wh.nh( _d, "c" ) : _d;
break;
case '!':
_a = rev( ops[1], e, s, g, o, _f );
_c = should_pass_type_info && (wh.hn( _a ) == 'h');
_d = !wh.rv(_a);
return _c ? wh.nh( _d, "c" ) : _d;
case '~':
_a = rev( ops[1], e, s, g, o, _f );
_c = should_pass_type_info && (wh.hn( _a ) == 'h');
_d = ~wh.rv(_a);
return _c ? wh.nh( _d, "c" ) : _d;
default:
$gwn('unrecognized op' + rop );
}
}
function rev( ops, e, s, g, o, newap )
{
var op = ops[0];
var _f = false;
if ( typeof newap !== "undefined" ) o.ap = newap;
if( typeof(op)==='object' )
{
var vop=op[0];
var _a, _aa, _b, _bb, _c, _d, _s, _e, _ta, _tb, _td;
switch(vop)
{
case 2:
return ArithmeticEv(ops,e,s,g,o);
break;
case 4: 
return rev( ops[1], e, s, g, o, _f );
break;
case 5: 
switch( ops.length )
{
case 2: 
_a = rev( ops[1],e,s,g,o,_f );
return should_pass_type_info?[_a]:[wh.rv(_a)];
return [_a];
break;
case 1: 
return [];
break;
default:
_a = rev( ops[1],e,s,g,o,_f );
_b = rev( ops[2],e,s,g,o,_f );
_a.push( 
should_pass_type_info ?
_b :
wh.rv( _b )
);
return _a;
break;
}
break;
case 6:
_a = rev(ops[1],e,s,g,o);
var ap = o.ap;
_ta = wh.hn(_a)==='h';
_aa = _ta ? wh.rv(_a) : _a;
o.is_affected |= _ta;
if( should_pass_type_info )
{
if( _aa===null || typeof(_aa) === 'undefined' )
{
return _ta ? wh.nh(undefined, 'e') : undefined;
}
_b = rev(ops[2],e,s,g,o,_f);
_tb = wh.hn(_b) === 'h';
_bb = _tb ? wh.rv(_b) : _b;
o.ap = ap;
o.is_affected |= _tb;
if( _bb===null || typeof(_bb) === 'undefined' || 
_bb === "__proto__" || _bb === "prototype" || _bb === "caller" ) 
{
return (_ta || _tb) ? wh.nh(undefined, 'e') : undefined;
}
_d = _aa[_bb];
if ( typeof _d === 'function' && !ap ) _d = undefined;
_td = wh.hn(_d)==='h';
o.is_affected |= _td;
return (_ta || _tb) ? (_td ? _d : wh.nh(_d, 'e')) : _d;
}
else
{
if( _aa===null || typeof(_aa) === 'undefined' )
{
return undefined;
}
_b = rev(ops[2],e,s,g,o,_f);
_tb = wh.hn(_b) === 'h';
_bb = _tb ? wh.rv(_b) : _b;
o.ap = ap;
o.is_affected |= _tb;
if( _bb===null || typeof(_bb) === 'undefined' || 
_bb === "__proto__" || _bb === "prototype" || _bb === "caller" ) 
{
return undefined;
}
_d = _aa[_bb];
if ( typeof _d === 'function' && !ap ) _d = undefined;
_td = wh.hn(_d)==='h';
o.is_affected |= _td;
return _td ? wh.rv(_d) : _d;
}
case 7: 
switch(ops[1][0])
{
case 11:
o.is_affected |= wh.hn(g)==='h';
return g;
case 3:
_s = wh.rv( s );
_e = wh.rv( e );
_b = ops[1][1];
if (g && g.f && g.f.hasOwnProperty(_b) )
{
_a = g.f;
o.ap = true;
}
else
{
_a = _s && _s.hasOwnProperty(_b) ? 
s : (_e && _e.hasOwnProperty(_b) ? e : undefined );
}
if( should_pass_type_info )
{
if( _a )
{
_ta = wh.hn(_a) === 'h';
_aa = _ta ? wh.rv( _a ) : _a;
_d = _aa[_b];
_td = wh.hn(_d) === 'h';
o.is_affected |= _ta || _td;
_d = _ta && !_td ? wh.nh(_d,'e') : _d;
return _d;
}
}
else
{
if( _a )
{
_ta = wh.hn(_a) === 'h';
_aa = _ta ? wh.rv( _a ) : _a;
_d = _aa[_b];
_td = wh.hn(_d) === 'h';
o.is_affected |= _ta || _td;
return wh.rv(_d);
}
}
return undefined;
}
break;
case 8: 
_a = {};
_a[ops[1]] = rev(ops[2],e,s,g,o,_f);
return _a;
break;
case 9: 
_a = rev(ops[1],e,s,g,o,_f);
_b = rev(ops[2],e,s,g,o,_f);
function merge( _a, _b, _ow )
{
var ka, _bbk;
_ta = wh.hn(_a)==='h';
_tb = wh.hn(_b)==='h';
_aa = wh.rv(_a);
_bb = wh.rv(_b);
for(var k in _bb)
{
if ( _ow || !_aa.hasOwnProperty(k) )
{
_aa[k] = should_pass_type_info ? (_tb ? wh.nh(_bb[k],'e') : _bb[k]) : wh.rv(_bb[k]);
}
}
return _a;
}
var _c = _a
var _ow = true
if ( typeof(ops[1][0]) === "object" && ops[1][0][0] === 10 ) {
_a = _b
_b = _c
_ow = false
}
if ( typeof(ops[1][0]) === "object" && ops[1][0][0] === 10 ) {
var _r = {}
return merge( merge( _r, _a, _ow ), _b, _ow );
}
else
return merge( _a, _b, _ow );
break;
case 10:
_a = rev(ops[1],e,s,g,o,_f);
_a = should_pass_type_info ? _a : wh.rv( _a );
return _a ;
break;
case 12:
var _r;
_a = rev(ops[1],e,s,g,o);
if ( !o.ap )
{
return should_pass_type_info && wh.hn(_a)==='h' ? wh.nh( _r, 'f' ) : _r;
}
var ap = o.ap;
_b = rev(ops[2],e,s,g,o,_f);
o.ap = ap;
_ta = wh.hn(_a)==='h';
_tb = _ca(_b);
_aa = wh.rv(_a);	
_bb = wh.rv(_b); snap_bb=$gdc(_bb,"nv_");
try{
_r = typeof _aa === "function" ? $gdc(_aa.apply(null, snap_bb)) : undefined;
} catch (e){
e.message = e.message.replace(/nv_/g,"");
e.stack = e.stack.substring(0,e.stack.indexOf("\n", e.stack.lastIndexOf("at nv_")));
e.stack = e.stack.replace(/\snv_/g," "); 
e.stack = $gstack(e.stack);	
if(g.debugInfo)
{
e.stack += "\n "+" "+" "+" at "+g.debugInfo[0]+":"+g.debugInfo[1]+":"+g.debugInfo[2];
console.error(e);
}
_r = undefined;
}
return should_pass_type_info && (_tb || _ta) ? wh.nh( _r, 'f' ) : _r;
}
}
else
{
if( op === 3 || op === 1) return ops[1];
else if( op === 11 ) 
{
var _a='';
for( var i = 1 ; i < ops.length ; i++ )
{
var xp = wh.rv(rev(ops[i],e,s,g,o,_f));
_a += typeof(xp) === 'undefined' ? '' : xp;
}
return _a;
}
}
}
function wrapper( ops, e, s, g, o, newap )
{
if( ops[0] == '11182016' )
{
g.debugInfo = ops[2];
return rev( ops[1], e, s, g, o, newap );
}
else
{
g.debugInfo = null;
return rev( ops, e, s, g, o, newap );
}
}
return wrapper;
}
gra=$gwrt(true); 
grb=$gwrt(false); 
function TestTest( expr, ops, e,s,g, expect_a, expect_b, expect_affected )
{
{
var o = {is_affected:false};
var a = gra( ops, e,s,g, o );
if( JSON.stringify(a) != JSON.stringify( expect_a )
|| o.is_affected != expect_affected )
{
console.warn( "A. " + expr + " get result " + JSON.stringify(a) + ", " + o.is_affected + ", but " + JSON.stringify( expect_a ) + ", " + expect_affected + " is expected" );
}
}
{
var o = {is_affected:false};
var a = grb( ops, e,s,g, o );
if( JSON.stringify(a) != JSON.stringify( expect_b )
|| o.is_affected != expect_affected )
{
console.warn( "B. " + expr + " get result " + JSON.stringify(a) + ", " + o.is_affected + ", but " + JSON.stringify( expect_b ) + ", " + expect_affected + " is expected" );
}
}
}

function wfor( to_iter, func, env, _s, global, father, itemname, indexname, keyname )
{
var _n = wh.hn( to_iter ) === 'n'; 
var scope = wh.rv( _s ); 
var has_old_item = scope.hasOwnProperty(itemname);
var has_old_index = scope.hasOwnProperty(indexname);
var old_item = scope[itemname];
var old_index = scope[indexname];
var full = Object.prototype.toString.call(wh.rv(to_iter));
var type = full[8]; 
if( type === 'N' && full[10] === 'l' ) type = 'X'; 
var _y;
if( _n )
{
if( type === 'A' ) 
{
var r_iter_item;
for( var i = 0 ; i < to_iter.length ; i++ )
{
scope[itemname] = to_iter[i];
scope[indexname] = _n ? i : wh.nh(i, 'h');
r_iter_item = wh.rv(to_iter[i]);
var key = keyname && r_iter_item ? (keyname==="*this" ? r_iter_item : wh.rv(r_iter_item[keyname])) : undefined;
_y = _v(key);
_(father,_y);
func( env, scope, _y, global );
}
}
else if( type === 'O' ) 
{
var i = 0;
var r_iter_item;
for( var k in to_iter )
{
scope[itemname] = to_iter[k];
scope[indexname] = _n ? k : wh.nh(k, 'h');
r_iter_item = wh.rv(to_iter[k]);
var key = keyname && r_iter_item ? (keyname==="*this" ? r_iter_item : wh.rv(r_iter_item[keyname])) : undefined;
_y = _v(key);
_(father,_y);
func( env,scope,_y,global );
i++;
}
}
else if( type === 'S' ) 
{
for( var i = 0 ; i < to_iter.length ; i++ )
{
scope[itemname] = to_iter[i];
scope[indexname] = _n ? i : wh.nh(i, 'h');
_y = _v( to_iter[i] + i );
_(father,_y);
func( env,scope,_y,global );
}
}
else if( type === 'N' ) 
{
for( var i = 0 ; i < to_iter ; i++ )
{
scope[itemname] = i;
scope[indexname] = _n ? i : wh.nh(i, 'h');
_y = _v( i );
_(father,_y);
func(env,scope,_y,global);
}
}
else
{
}
}
else
{
var r_to_iter = wh.rv(to_iter);
var r_iter_item, iter_item;
if( type === 'A' ) 
{
for( var i = 0 ; i < r_to_iter.length ; i++ )
{
iter_item = r_to_iter[i];
iter_item = wh.hn(iter_item)==='n' ? wh.nh(iter_item,'h') : iter_item;
r_iter_item = wh.rv( iter_item );
scope[itemname] = iter_item
scope[indexname] = _n ? i : wh.nh(i, 'h');
var key = keyname && r_iter_item ? (keyname==="*this" ? r_iter_item : wh.rv(r_iter_item[keyname])) : undefined;
_y = _v(key);
_(father,_y);
func( env, scope, _y, global );
}
}
else if( type === 'O' ) 
{
var i=0;
for( var k in r_to_iter )
{
iter_item = r_to_iter[k];
iter_item = wh.hn(iter_item)==='n'? wh.nh(iter_item,'h') : iter_item;
r_iter_item = wh.rv( iter_item );
scope[itemname] = iter_item;
scope[indexname] = _n ? k : wh.nh(k, 'h');
var key = keyname && r_iter_item ? (keyname==="*this" ? r_iter_item : wh.rv(r_iter_item[keyname])) : undefined;
_y=_v(key);
_(father,_y);
func( env, scope, _y, global );
i++
}
}
else if( type === 'S' ) 
{
for( var i = 0 ; i < r_to_iter.length ; i++ )
{
iter_item = wh.nh(r_to_iter[i],'h');
scope[itemname] = iter_item;
scope[indexname] = _n ? i : wh.nh(i, 'h');
_y = _v( to_iter[i] + i );
_(father,_y);
func( env, scope, _y, global );
}
}
else if( type === 'N' ) 
{
for( var i = 0 ; i < r_to_iter ; i++ )
{
iter_item = wh.nh(i,'h');
scope[itemname] = iter_item;
scope[indexname]= _n ? i : wh.nh(i,'h');
_y = _v( i );
_(father,_y);
func(env,scope,_y,global);
}
}
else
{
}
}
if(has_old_item)
{
scope[itemname]=old_item;
}
else
{
delete scope[itemname];
}
if(has_old_index)
{
scope[indexname]=old_index;
}
else
{
delete scope[indexname];
}
}

function _ca(o)
{ 
if ( wh.hn(o) == 'h' ) return true;
if ( typeof o !== "object" ) return false;
for(var i in o){ 
if ( o.hasOwnProperty(i) ){
if (_ca(o[i])) return true;
}
}
return false;
}
function _da( node, attrname, opindex, raw, o )
{
var isaffected = false;
var value = $gdc( raw, "", 2 );
if ( o.ap && value && value.constructor===Function ) 
{
attrname = "$wxs:" + attrname; 
node.attr["$gdc"] = $gdc;
}
if ( o.is_affected || _ca(raw) ) 
{
node.n.push( attrname );
node.raw[attrname] = raw;
}
node.attr[attrname] = value;
}
function _r( node, attrname, opindex, env, scope, global ) 
{
global.opindex=opindex;
var o = {}, _env;
var a = grb( z[opindex], env, scope, global, o );
_da( node, attrname, opindex, a, o );
}
function _rz( z, node, attrname, opindex, env, scope, global ) 
{
global.opindex=opindex;
var o = {}, _env;
var a = grb( z[opindex], env, scope, global, o );
_da( node, attrname, opindex, a, o );
}
function _o( opindex, env, scope, global )
{
global.opindex=opindex;
var nothing = {};
var r = grb( z[opindex], env, scope, global, nothing );
return (r&&r.constructor===Function) ? undefined : r;
}
function _oz( z, opindex, env, scope, global )
{
global.opindex=opindex;
var nothing = {};
var r = grb( z[opindex], env, scope, global, nothing );
return (r&&r.constructor===Function) ? undefined : r;
}
function _1( opindex, env, scope, global, o )
{
var o = o || {};
global.opindex=opindex;
return gra( z[opindex], env, scope, global, o );
}
function _1z( z, opindex, env, scope, global, o )
{
var o = o || {};
global.opindex=opindex;
return gra( z[opindex], env, scope, global, o );
}
function _2( opindex, func, env, scope, global, father, itemname, indexname, keyname )
{
var o = {};
var to_iter = _1( opindex, env, scope, global );
wfor( to_iter, func, env, scope, global, father, itemname, indexname, keyname );
}
function _2z( z, opindex, func, env, scope, global, father, itemname, indexname, keyname )
{
var o = {};
var to_iter = _1z( z, opindex, env, scope, global );
wfor( to_iter, func, env, scope, global, father, itemname, indexname, keyname );
}


function _m(tag,attrs,generics,env,scope,global)
{
var tmp=_n(tag);
var base=0;
for(var i = 0 ; i < attrs.length ; i+=2 )
{
if(base+attrs[i+1]<0)
{
tmp.attr[attrs[i]]=true;
}
else
{
_r(tmp,attrs[i],base+attrs[i+1],env,scope,global);
if(base===0)base=attrs[i+1];
}
}
for(var i=0;i<generics.length;i+=2)
{
if(base+generics[i+1]<0)
{
tmp.generics[generics[i]]="";
}
else
{
var $t=grb(z[base+generics[i+1]],env,scope,global);
if ($t!="") $t="wx-"+$t;
tmp.generics[generics[i]]=$t;
if(base===0)base=generics[i+1];
}
}
return tmp;
}
function _mz(z,tag,attrs,generics,env,scope,global)
{
var tmp=_n(tag);
var base=0;
for(var i = 0 ; i < attrs.length ; i+=2 )
{
if(base+attrs[i+1]<0)
{
tmp.attr[attrs[i]]=true;
}
else
{
_rz(z, tmp,attrs[i],base+attrs[i+1],env,scope,global);
if(base===0)base=attrs[i+1];
}
}
for(var i=0;i<generics.length;i+=2)
{
if(base+generics[i+1]<0)
{
tmp.generics[generics[i]]="";
}
else
{
var $t=grb(z[base+generics[i+1]],env,scope,global);
if ($t!="") $t="wx-"+$t;
tmp.generics[generics[i]]=$t;
if(base===0)base=generics[i+1];
}
}
return tmp;
}

var nf_init=function(){
if(typeof __WXML_GLOBAL__==="undefined"||undefined===__WXML_GLOBAL__.wxs_nf_init){
nf_init_Object();nf_init_Function();nf_init_Array();nf_init_String();nf_init_Boolean();nf_init_Number();nf_init_Math();nf_init_Date();nf_init_RegExp();
}
if(typeof __WXML_GLOBAL__!=="undefined") __WXML_GLOBAL__.wxs_nf_init=true;
};
var nf_init_Object=function(){
Object.defineProperty(Object.prototype,"nv_constructor",{writable:true,value:"Object"})
Object.defineProperty(Object.prototype,"nv_toString",{writable:true,value:function(){return "[object Object]"}})
}
var nf_init_Function=function(){
Object.defineProperty(Function.prototype,"nv_constructor",{writable:true,value:"Function"})
Object.defineProperty(Function.prototype,"nv_length",{get:function(){return this.length;},set:function(){}});
Object.defineProperty(Function.prototype,"nv_toString",{writable:true,value:function(){return "[function Function]"}})
}
var nf_init_Array=function(){
Object.defineProperty(Array.prototype,"nv_toString",{writable:true,value:function(){return this.nv_join();}})
Object.defineProperty(Array.prototype,"nv_join",{writable:true,value:function(s){
s=undefined==s?',':s;
var r="";
for(var i=0;i<this.length;++i){
if(0!=i) r+=s;
if(null==this[i]||undefined==this[i]) r+='';	
else if(typeof this[i]=='function') r+=this[i].nv_toString();
else if(typeof this[i]=='object'&&this[i].nv_constructor==="Array") r+=this[i].nv_join();
else r+=this[i].toString();
}
return r;
}})
Object.defineProperty(Array.prototype,"nv_constructor",{writable:true,value:"Array"})
Object.defineProperty(Array.prototype,"nv_concat",{writable:true,value:Array.prototype.concat})
Object.defineProperty(Array.prototype,"nv_pop",{writable:true,value:Array.prototype.pop})
Object.defineProperty(Array.prototype,"nv_push",{writable:true,value:Array.prototype.push})
Object.defineProperty(Array.prototype,"nv_reverse",{writable:true,value:Array.prototype.reverse})
Object.defineProperty(Array.prototype,"nv_shift",{writable:true,value:Array.prototype.shift})
Object.defineProperty(Array.prototype,"nv_slice",{writable:true,value:Array.prototype.slice})
Object.defineProperty(Array.prototype,"nv_sort",{writable:true,value:Array.prototype.sort})
Object.defineProperty(Array.prototype,"nv_splice",{writable:true,value:Array.prototype.splice})
Object.defineProperty(Array.prototype,"nv_unshift",{writable:true,value:Array.prototype.unshift})
Object.defineProperty(Array.prototype,"nv_indexOf",{writable:true,value:Array.prototype.indexOf})
Object.defineProperty(Array.prototype,"nv_lastIndexOf",{writable:true,value:Array.prototype.lastIndexOf})
Object.defineProperty(Array.prototype,"nv_every",{writable:true,value:Array.prototype.every})
Object.defineProperty(Array.prototype,"nv_some",{writable:true,value:Array.prototype.some})
Object.defineProperty(Array.prototype,"nv_forEach",{writable:true,value:Array.prototype.forEach})
Object.defineProperty(Array.prototype,"nv_map",{writable:true,value:Array.prototype.map})
Object.defineProperty(Array.prototype,"nv_filter",{writable:true,value:Array.prototype.filter})
Object.defineProperty(Array.prototype,"nv_reduce",{writable:true,value:Array.prototype.reduce})
Object.defineProperty(Array.prototype,"nv_reduceRight",{writable:true,value:Array.prototype.reduceRight})
Object.defineProperty(Array.prototype,"nv_length",{get:function(){return this.length;},set:function(value){this.length=value;}});
}
var nf_init_String=function(){
Object.defineProperty(String.prototype,"nv_constructor",{writable:true,value:"String"})
Object.defineProperty(String.prototype,"nv_toString",{writable:true,value:String.prototype.toString})
Object.defineProperty(String.prototype,"nv_valueOf",{writable:true,value:String.prototype.valueOf})
Object.defineProperty(String.prototype,"nv_charAt",{writable:true,value:String.prototype.charAt})
Object.defineProperty(String.prototype,"nv_charCodeAt",{writable:true,value:String.prototype.charCodeAt})
Object.defineProperty(String.prototype,"nv_concat",{writable:true,value:String.prototype.concat})
Object.defineProperty(String.prototype,"nv_indexOf",{writable:true,value:String.prototype.indexOf})
Object.defineProperty(String.prototype,"nv_lastIndexOf",{writable:true,value:String.prototype.lastIndexOf})
Object.defineProperty(String.prototype,"nv_localeCompare",{writable:true,value:String.prototype.localeCompare})
Object.defineProperty(String.prototype,"nv_match",{writable:true,value:String.prototype.match})
Object.defineProperty(String.prototype,"nv_replace",{writable:true,value:String.prototype.replace})
Object.defineProperty(String.prototype,"nv_search",{writable:true,value:String.prototype.search})
Object.defineProperty(String.prototype,"nv_slice",{writable:true,value:String.prototype.slice})
Object.defineProperty(String.prototype,"nv_split",{writable:true,value:String.prototype.split})
Object.defineProperty(String.prototype,"nv_substring",{writable:true,value:String.prototype.substring})
Object.defineProperty(String.prototype,"nv_toLowerCase",{writable:true,value:String.prototype.toLowerCase})
Object.defineProperty(String.prototype,"nv_toLocaleLowerCase",{writable:true,value:String.prototype.toLocaleLowerCase})
Object.defineProperty(String.prototype,"nv_toUpperCase",{writable:true,value:String.prototype.toUpperCase})
Object.defineProperty(String.prototype,"nv_toLocaleUpperCase",{writable:true,value:String.prototype.toLocaleUpperCase})
Object.defineProperty(String.prototype,"nv_trim",{writable:true,value:String.prototype.trim})
Object.defineProperty(String.prototype,"nv_length",{get:function(){return this.length;},set:function(value){this.length=value;}});
}
var nf_init_Boolean=function(){
Object.defineProperty(Boolean.prototype,"nv_constructor",{writable:true,value:"Boolean"})
Object.defineProperty(Boolean.prototype,"nv_toString",{writable:true,value:Boolean.prototype.toString})
Object.defineProperty(Boolean.prototype,"nv_valueOf",{writable:true,value:Boolean.prototype.valueOf})
}
var nf_init_Number=function(){
Object.defineProperty(Number,"nv_MAX_VALUE",{writable:false,value:Number.MAX_VALUE})
Object.defineProperty(Number,"nv_MIN_VALUE",{writable:false,value:Number.MIN_VALUE})
Object.defineProperty(Number,"nv_NEGATIVE_INFINITY",{writable:false,value:Number.NEGATIVE_INFINITY})
Object.defineProperty(Number,"nv_POSITIVE_INFINITY",{writable:false,value:Number.POSITIVE_INFINITY})
Object.defineProperty(Number.prototype,"nv_constructor",{writable:true,value:"Number"})
Object.defineProperty(Number.prototype,"nv_toString",{writable:true,value:Number.prototype.toString})
Object.defineProperty(Number.prototype,"nv_toLocaleString",{writable:true,value:Number.prototype.toLocaleString})
Object.defineProperty(Number.prototype,"nv_valueOf",{writable:true,value:Number.prototype.valueOf})
Object.defineProperty(Number.prototype,"nv_toFixed",{writable:true,value:Number.prototype.toFixed})
Object.defineProperty(Number.prototype,"nv_toExponential",{writable:true,value:Number.prototype.toExponential})
Object.defineProperty(Number.prototype,"nv_toPrecision",{writable:true,value:Number.prototype.toPrecision})
}
var nf_init_Math=function(){
Object.defineProperty(Math,"nv_E",{writable:false,value:Math.E})
Object.defineProperty(Math,"nv_LN10",{writable:false,value:Math.LN10})
Object.defineProperty(Math,"nv_LN2",{writable:false,value:Math.LN2})
Object.defineProperty(Math,"nv_LOG2E",{writable:false,value:Math.LOG2E})
Object.defineProperty(Math,"nv_LOG10E",{writable:false,value:Math.LOG10E})
Object.defineProperty(Math,"nv_PI",{writable:false,value:Math.PI})
Object.defineProperty(Math,"nv_SQRT1_2",{writable:false,value:Math.SQRT1_2})
Object.defineProperty(Math,"nv_SQRT2",{writable:false,value:Math.SQRT2})
Object.defineProperty(Math,"nv_abs",{writable:false,value:Math.abs})
Object.defineProperty(Math,"nv_acos",{writable:false,value:Math.acos})
Object.defineProperty(Math,"nv_asin",{writable:false,value:Math.asin})
Object.defineProperty(Math,"nv_atan",{writable:false,value:Math.atan})
Object.defineProperty(Math,"nv_atan2",{writable:false,value:Math.atan2})
Object.defineProperty(Math,"nv_ceil",{writable:false,value:Math.ceil})
Object.defineProperty(Math,"nv_cos",{writable:false,value:Math.cos})
Object.defineProperty(Math,"nv_exp",{writable:false,value:Math.exp})
Object.defineProperty(Math,"nv_floor",{writable:false,value:Math.floor})
Object.defineProperty(Math,"nv_log",{writable:false,value:Math.log})
Object.defineProperty(Math,"nv_max",{writable:false,value:Math.max})
Object.defineProperty(Math,"nv_min",{writable:false,value:Math.min})
Object.defineProperty(Math,"nv_pow",{writable:false,value:Math.pow})
Object.defineProperty(Math,"nv_random",{writable:false,value:Math.random})
Object.defineProperty(Math,"nv_round",{writable:false,value:Math.round})
Object.defineProperty(Math,"nv_sin",{writable:false,value:Math.sin})
Object.defineProperty(Math,"nv_sqrt",{writable:false,value:Math.sqrt})
Object.defineProperty(Math,"nv_tan",{writable:false,value:Math.tan})
}
var nf_init_Date=function(){
Object.defineProperty(Date.prototype,"nv_constructor",{writable:true,value:"Date"})
Object.defineProperty(Date,"nv_parse",{writable:true,value:Date.parse})
Object.defineProperty(Date,"nv_UTC",{writable:true,value:Date.UTC})
Object.defineProperty(Date,"nv_now",{writable:true,value:Date.now})
Object.defineProperty(Date.prototype,"nv_toString",{writable:true,value:Date.prototype.toString})
Object.defineProperty(Date.prototype,"nv_toDateString",{writable:true,value:Date.prototype.toDateString})
Object.defineProperty(Date.prototype,"nv_toTimeString",{writable:true,value:Date.prototype.toTimeString})
Object.defineProperty(Date.prototype,"nv_toLocaleString",{writable:true,value:Date.prototype.toLocaleString})
Object.defineProperty(Date.prototype,"nv_toLocaleDateString",{writable:true,value:Date.prototype.toLocaleDateString})
Object.defineProperty(Date.prototype,"nv_toLocaleTimeString",{writable:true,value:Date.prototype.toLocaleTimeString})
Object.defineProperty(Date.prototype,"nv_valueOf",{writable:true,value:Date.prototype.valueOf})
Object.defineProperty(Date.prototype,"nv_getTime",{writable:true,value:Date.prototype.getTime})
Object.defineProperty(Date.prototype,"nv_getFullYear",{writable:true,value:Date.prototype.getFullYear})
Object.defineProperty(Date.prototype,"nv_getUTCFullYear",{writable:true,value:Date.prototype.getUTCFullYear})
Object.defineProperty(Date.prototype,"nv_getMonth",{writable:true,value:Date.prototype.getMonth})
Object.defineProperty(Date.prototype,"nv_getUTCMonth",{writable:true,value:Date.prototype.getUTCMonth})
Object.defineProperty(Date.prototype,"nv_getDate",{writable:true,value:Date.prototype.getDate})
Object.defineProperty(Date.prototype,"nv_getUTCDate",{writable:true,value:Date.prototype.getUTCDate})
Object.defineProperty(Date.prototype,"nv_getDay",{writable:true,value:Date.prototype.getDay})
Object.defineProperty(Date.prototype,"nv_getUTCDay",{writable:true,value:Date.prototype.getUTCDay})
Object.defineProperty(Date.prototype,"nv_getHours",{writable:true,value:Date.prototype.getHours})
Object.defineProperty(Date.prototype,"nv_getUTCHours",{writable:true,value:Date.prototype.getUTCHours})
Object.defineProperty(Date.prototype,"nv_getMinutes",{writable:true,value:Date.prototype.getMinutes})
Object.defineProperty(Date.prototype,"nv_getUTCMinutes",{writable:true,value:Date.prototype.getUTCMinutes})
Object.defineProperty(Date.prototype,"nv_getSeconds",{writable:true,value:Date.prototype.getSeconds})
Object.defineProperty(Date.prototype,"nv_getUTCSeconds",{writable:true,value:Date.prototype.getUTCSeconds})
Object.defineProperty(Date.prototype,"nv_getMilliseconds",{writable:true,value:Date.prototype.getMilliseconds})
Object.defineProperty(Date.prototype,"nv_getUTCMilliseconds",{writable:true,value:Date.prototype.getUTCMilliseconds})
Object.defineProperty(Date.prototype,"nv_getTimezoneOffset",{writable:true,value:Date.prototype.getTimezoneOffset})
Object.defineProperty(Date.prototype,"nv_setTime",{writable:true,value:Date.prototype.setTime})
Object.defineProperty(Date.prototype,"nv_setMilliseconds",{writable:true,value:Date.prototype.setMilliseconds})
Object.defineProperty(Date.prototype,"nv_setUTCMilliseconds",{writable:true,value:Date.prototype.setUTCMilliseconds})
Object.defineProperty(Date.prototype,"nv_setSeconds",{writable:true,value:Date.prototype.setSeconds})
Object.defineProperty(Date.prototype,"nv_setUTCSeconds",{writable:true,value:Date.prototype.setUTCSeconds})
Object.defineProperty(Date.prototype,"nv_setMinutes",{writable:true,value:Date.prototype.setMinutes})
Object.defineProperty(Date.prototype,"nv_setUTCMinutes",{writable:true,value:Date.prototype.setUTCMinutes})
Object.defineProperty(Date.prototype,"nv_setHours",{writable:true,value:Date.prototype.setHours})
Object.defineProperty(Date.prototype,"nv_setUTCHours",{writable:true,value:Date.prototype.setUTCHours})
Object.defineProperty(Date.prototype,"nv_setDate",{writable:true,value:Date.prototype.setDate})
Object.defineProperty(Date.prototype,"nv_setUTCDate",{writable:true,value:Date.prototype.setUTCDate})
Object.defineProperty(Date.prototype,"nv_setMonth",{writable:true,value:Date.prototype.setMonth})
Object.defineProperty(Date.prototype,"nv_setUTCMonth",{writable:true,value:Date.prototype.setUTCMonth})
Object.defineProperty(Date.prototype,"nv_setFullYear",{writable:true,value:Date.prototype.setFullYear})
Object.defineProperty(Date.prototype,"nv_setUTCFullYear",{writable:true,value:Date.prototype.setUTCFullYear})
Object.defineProperty(Date.prototype,"nv_toUTCString",{writable:true,value:Date.prototype.toUTCString})
Object.defineProperty(Date.prototype,"nv_toISOString",{writable:true,value:Date.prototype.toISOString})
Object.defineProperty(Date.prototype,"nv_toJSON",{writable:true,value:Date.prototype.toJSON})
}
var nf_init_RegExp=function(){
Object.defineProperty(RegExp.prototype,"nv_constructor",{writable:true,value:"RegExp"})
Object.defineProperty(RegExp.prototype,"nv_exec",{writable:true,value:RegExp.prototype.exec})
Object.defineProperty(RegExp.prototype,"nv_test",{writable:true,value:RegExp.prototype.test})
Object.defineProperty(RegExp.prototype,"nv_toString",{writable:true,value:RegExp.prototype.toString})
Object.defineProperty(RegExp.prototype,"nv_source",{get:function(){return this.source;},set:function(){}});
Object.defineProperty(RegExp.prototype,"nv_global",{get:function(){return this.global;},set:function(){}});
Object.defineProperty(RegExp.prototype,"nv_ignoreCase",{get:function(){return this.ignoreCase;},set:function(){}});
Object.defineProperty(RegExp.prototype,"nv_multiline",{get:function(){return this.multiline;},set:function(){}});
Object.defineProperty(RegExp.prototype,"nv_lastIndex",{get:function(){return this.lastIndex;},set:function(v){this.lastIndex=v;}});
}
nf_init();
var nv_getDate=function(){var args=Array.prototype.slice.call(arguments);args.unshift(Date);return new(Function.prototype.bind.apply(Date, args));}
var nv_getRegExp=function(){var args=Array.prototype.slice.call(arguments);args.unshift(RegExp);return new(Function.prototype.bind.apply(RegExp, args));}
var nv_console={}
nv_console.nv_log=function(){var res="WXSRT:";for(var i=0;i<arguments.length;++i)res+=arguments[i]+" ";console.log(res);}
var nv_parseInt = parseInt, nv_parseFloat = parseFloat, nv_isNaN = isNaN, nv_isFinite = isFinite, nv_decodeURI = decodeURI, nv_decodeURIComponent = decodeURIComponent, nv_encodeURI = encodeURI, nv_encodeURIComponent = encodeURIComponent;
function $gdc(o,p,r) {
o=wh.rv(o);
if(o===null||o===undefined) return o;
if(o.constructor===String||o.constructor===Boolean||o.constructor===Number) return o;
if(o.constructor===Object){
var copy={};
for(var k in o)
if(o.hasOwnProperty(k))
if(undefined===p) copy[k.substring(3)]=$gdc(o[k],p,r);
else copy[p+k]=$gdc(o[k],p,r);
return copy;
}
if(o.constructor===Array){
var copy=[];
for(var i=0;i<o.length;i++) copy.push($gdc(o[i],p,r));
return copy;
}
if(o.constructor===Date){
var copy=new Date();
copy.setTime(o.getTime());
return copy;
}
if(o.constructor===RegExp){
var f="";
if(o.global) f+="g";
if(o.ignoreCase) f+="i";
if(o.multiline) f+="m";
return (new RegExp(o.source,f));
}
if(r&&o.constructor===Function){
if ( r == 1 ) return $gdc(o(),undefined, 2);
if ( r == 2 ) return o;
}
return null;
}
var nv_JSON={}
nv_JSON.nv_stringify=function(o){
JSON.stringify(o);
return JSON.stringify($gdc(o));
}
nv_JSON.nv_parse=function(o){
if(o===undefined) return undefined;
var t=JSON.parse(o);
return $gdc(t,'nv_');
}

function _af(p, a, c){
p.extraAttr = {"t_action": a, "t_cid": c};
}

function _ai(i,p,e,me,r,c){var x=_grp(p,e,me);if(x)i.push(x);else{i.push('');_wp(me+':import:'+r+':'+c+': Path `'+p+'` not found from `'+me+'`.')}}
function _grp(p,e,me){if(p[0]!='/'){var mepart=me.split('/');mepart.pop();var ppart=p.split('/');for(var i=0;i<ppart.length;i++){if( ppart[i]=='..')mepart.pop();else if(!ppart[i]||ppart[i]=='.')continue;else mepart.push(ppart[i]);}p=mepart.join('/');}if(me[0]=='.'&&p[0]=='/')p='.'+p;if(e[p])return p;if(e[p+'.wxml'])return p+'.wxml';}
function _gd(p,c,e,d){if(!c)return;if(d[p][c])return d[p][c];for(var x=e[p].i.length-1;x>=0;x--){if(e[p].i[x]&&d[e[p].i[x]][c])return d[e[p].i[x]][c]};for(var x=e[p].ti.length-1;x>=0;x--){var q=_grp(e[p].ti[x],e,p);if(q&&d[q][c])return d[q][c]}var ii=_gapi(e,p);for(var x=0;x<ii.length;x++){if(ii[x]&&d[ii[x]][c])return d[ii[x]][c]}for(var k=e[p].j.length-1;k>=0;k--)if(e[p].j[k]){for(var q=e[e[p].j[k]].ti.length-1;q>=0;q--){var pp=_grp(e[e[p].j[k]].ti[q],e,p);if(pp&&d[pp][c]){return d[pp][c]}}}}
function _gapi(e,p){if(!p)return [];if($gaic[p]){return $gaic[p]};var ret=[],q=[],h=0,t=0,put={},visited={};q.push(p);visited[p]=true;t++;while(h<t){var a=q[h++];for(var i=0;i<e[a].ic.length;i++){var nd=e[a].ic[i];var np=_grp(nd,e,a);if(np&&!visited[np]){visited[np]=true;q.push(np);t++;}}for(var i=0;a!=p&&i<e[a].ti.length;i++){var ni=e[a].ti[i];var nm=_grp(ni,e,a);if(nm&&!put[nm]){put[nm]=true;ret.push(nm);}}}$gaic[p]=ret;return ret;}
var $ixc={};function _ic(p,ent,me,e,s,r,gg){var x=_grp(p,ent,me);ent[me].j.push(x);if(x){if($ixc[x]){_wp('-1:include:-1:-1: `'+p+'` is being included in a loop, will be stop.');return;}$ixc[x]=true;try{ent[x].f(e,s,r,gg)}catch(e){}$ixc[x]=false;}else{_wp(me+':include:-1:-1: Included path `'+p+'` not found from `'+me+'`.')}}
function _w(tn,f,line,c){_wp(f+':template:'+line+':'+c+': Template `'+tn+'` not found.');}function _ev(dom){var changed=false;delete dom.properities;delete dom.n;if(dom.children){do{changed=false;var newch = [];for(var i=0;i<dom.children.length;i++){var ch=dom.children[i];if( ch.tag=='virtual'){changed=true;for(var j=0;ch.children&&j<ch.children.length;j++){newch.push(ch.children[j]);}}else { newch.push(ch); } } dom.children = newch; }while(changed);for(var i=0;i<dom.children.length;i++){_ev(dom.children[i]);}} return dom; }
function _tsd( root )
{
if( root.tag == "wx-wx-scope" ) 
{
root.tag = "virtual";
root.wxCkey = "11";
root['wxScopeData'] = root.attr['wx:scope-data'];
delete root.n;
delete root.raw;
delete root.generics;
delete root.attr;
}
for( var i = 0 ; root.children && i < root.children.length ; i++ )
{
_tsd( root.children[i] );
}
return root;
}

var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx || [];
function gz$gwx_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_1)return __WXML_GLOBAL__.ops_cached.$gwx_1
__WXML_GLOBAL__.ops_cached.$gwx_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_1);return __WXML_GLOBAL__.ops_cached.$gwx_1
}
function gz$gwx_2(){
if( __WXML_GLOBAL__.ops_cached.$gwx_2)return __WXML_GLOBAL__.ops_cached.$gwx_2
__WXML_GLOBAL__.ops_cached.$gwx_2=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'container'])
Z([[2,'==='],[[6],[[7],[3,'listTitle']],[3,'length']],[1,0]])
Z([3,'titleItems'])
Z([[7],[3,'listTitle']])
Z([3,'*this'])
Z([3,'details'])
Z([[7],[3,'budgetList']])
Z([3,'unique'])
Z([[2,'==='],[[7],[3,'titleItems']],[[6],[[7],[3,'details']],[3,'title']]])
})(__WXML_GLOBAL__.ops_cached.$gwx_2);return __WXML_GLOBAL__.ops_cached.$gwx_2
}
function gz$gwx_3(){
if( __WXML_GLOBAL__.ops_cached.$gwx_3)return __WXML_GLOBAL__.ops_cached.$gwx_3
__WXML_GLOBAL__.ops_cached.$gwx_3=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_3);return __WXML_GLOBAL__.ops_cached.$gwx_3
}
function gz$gwx_4(){
if( __WXML_GLOBAL__.ops_cached.$gwx_4)return __WXML_GLOBAL__.ops_cached.$gwx_4
__WXML_GLOBAL__.ops_cached.$gwx_4=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[2,'==='],[[6],[[7],[3,'historyList']],[3,'length']],[1,0]])
})(__WXML_GLOBAL__.ops_cached.$gwx_4);return __WXML_GLOBAL__.ops_cached.$gwx_4
}
function gz$gwx_5(){
if( __WXML_GLOBAL__.ops_cached.$gwx_5)return __WXML_GLOBAL__.ops_cached.$gwx_5
__WXML_GLOBAL__.ops_cached.$gwx_5=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'container'])
Z([[2,'?:'],[[7],[3,'hasUserInfo']],[1,'bindGoPersonal'],[1,'']])
Z([3,'userinfo'])
Z([[2,'!'],[[7],[3,'hasUserInfo']]])
Z([3,'notice'])
Z([[2,'&&'],[[2,'!='],[[7],[3,'floadTaskInfo']],[1,null]],[[2,'!'],[[6],[[6],[[7],[3,'floadTaskInfo']],[3,'pageReward']],[3,'type2']]]])
Z([[2,'?:'],[[2,'==='],[[7],[3,'authWeRun']],[1,2]],[1,''],[1,'bindShowGetSteps']])
Z([3,'float-items float-coin'])
Z([3,'2'])
Z([[2,'==='],[[7],[3,'authWeRun']],[1,2]])
Z([[2,'&&'],[[2,'&&'],[[2,'!='],[[7],[3,'floadTaskInfo']],[1,null]],[[2,'!'],[[6],[[6],[[7],[3,'floadTaskInfo']],[3,'pageReward']],[3,'type4']]]],[[7],[3,'isCanVideoAd']]])
Z([[2,'!='],[[7],[3,'floadTaskInfo']],[1,null]])
Z(z[11])
Z([3,'bindGoReward1'])
Z([3,'float-invite'])
Z([[6],[[6],[[6],[[7],[3,'floadTaskInfo']],[3,'pageReward']],[3,'type1']],[3,'redEnvelopeId']])
Z([3,'1'])
Z([[2,'==='],[[6],[[6],[[6],[[7],[3,'floadTaskInfo']],[3,'pageReward']],[3,'type1']],[3,'size']],[1,0]])
Z([[2,'>'],[[6],[[6],[[6],[[7],[3,'floadTaskInfo']],[3,'pageReward']],[3,'type1']],[3,'size']],[1,0]])
Z([[2,'?:'],[[2,'==='],[[7],[3,'authWeRun']],[1,2]],[1,''],[1,'bindGoPersonal']])
Z([3,'step-details'])
Z(z[9])
Z([[2,'&&'],[[6],[[7],[3,'tencentADList']],[1,0]],[[6],[[6],[[7],[3,'tencentADList']],[1,0]],[3,'openFlag']]])
Z([[6],[[7],[3,'allTaskObj']],[3,'TASK_SWITCH']])
Z([3,'task-component'])
Z([[7],[3,'taskObj']])
Z([[6],[[7],[3,'allTaskObj']],[3,'BOUTIQUE_SWITCH']])
Z([3,'return'])
Z([3,'modal-dialog'])
Z([[7],[3,'invitedResModal']])
Z([[6],[[6],[[7],[3,'userInfo']],[3,'referrerInfo']],[3,'userHeadImg']])
Z(z[27])
Z(z[28])
Z([[6],[[7],[3,'openRedModal']],[3,'status']])
Z([[2,'&&'],[[6],[[7],[3,'tencentADList']],[1,2]],[[6],[[6],[[7],[3,'tencentADList']],[1,2]],[3,'openFlag']]])
Z(z[27])
Z(z[28])
Z([[7],[3,'failModal']])
Z(z[34])
Z(z[27])
Z(z[28])
Z([[7],[3,'getStepsModal']])
Z(z[34])
Z(z[27])
Z(z[28])
Z([[7],[3,'videoRewardModal']])
Z([[6],[[7],[3,'tencentADList']],[1,2]])
Z(z[27])
Z(z[28])
Z([[2,'!'],[[7],[3,'jumpModal']]])
Z(z[34])
Z(z[27])
Z(z[28])
Z([[2,'!'],[[6],[[7],[3,'systemInforms']],[3,'maintenanceNoticeFlag']]])
Z([[6],[[7],[3,'systemInforms']],[3,'closeFlag']])
})(__WXML_GLOBAL__.ops_cached.$gwx_5);return __WXML_GLOBAL__.ops_cached.$gwx_5
}
function gz$gwx_6(){
if( __WXML_GLOBAL__.ops_cached.$gwx_6)return __WXML_GLOBAL__.ops_cached.$gwx_6
__WXML_GLOBAL__.ops_cached.$gwx_6=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'formSubmit'])
Z([3,'true'])
Z([[2,'==='],[[6],[[7],[3,'rewardList']],[3,'length']],[1,0]])
Z([3,'return'])
Z([3,'modal-dialog'])
Z([[7],[3,'openRedModal']])
Z([[2,'&&'],[[6],[[7],[3,'tencentADList']],[1,2]],[[6],[[6],[[7],[3,'tencentADList']],[1,2]],[3,'openFlag']]])
})(__WXML_GLOBAL__.ops_cached.$gwx_6);return __WXML_GLOBAL__.ops_cached.$gwx_6
}
function gz$gwx_7(){
if( __WXML_GLOBAL__.ops_cached.$gwx_7)return __WXML_GLOBAL__.ops_cached.$gwx_7
__WXML_GLOBAL__.ops_cached.$gwx_7=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'container'])
Z([[2,'==='],[[6],[[7],[3,'rankingList']],[3,'length']],[1,0]])
Z([[2,'&&'],[[6],[[7],[3,'tencentADList']],[1,0]],[[6],[[6],[[7],[3,'tencentADList']],[1,0]],[3,'openFlag']]])
})(__WXML_GLOBAL__.ops_cached.$gwx_7);return __WXML_GLOBAL__.ops_cached.$gwx_7
}
function gz$gwx_8(){
if( __WXML_GLOBAL__.ops_cached.$gwx_8)return __WXML_GLOBAL__.ops_cached.$gwx_8
__WXML_GLOBAL__.ops_cached.$gwx_8=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_8);return __WXML_GLOBAL__.ops_cached.$gwx_8
}
function gz$gwx_9(){
if( __WXML_GLOBAL__.ops_cached.$gwx_9)return __WXML_GLOBAL__.ops_cached.$gwx_9
__WXML_GLOBAL__.ops_cached.$gwx_9=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[2,'&&'],[[6],[[7],[3,'tencentADList']],[1,1]],[[6],[[6],[[7],[3,'tencentADList']],[1,1]],[3,'openFlag']]])
Z([3,'modal-dialog'])
Z([[7],[3,'takeModal']])
Z([[7],[3,'canTakeStatus']])
Z([[2,'&&'],[[6],[[7],[3,'tencentADList']],[1,2]],[[6],[[6],[[7],[3,'tencentADList']],[1,2]],[3,'openFlag']]])
Z(z[4])
})(__WXML_GLOBAL__.ops_cached.$gwx_9);return __WXML_GLOBAL__.ops_cached.$gwx_9
}
function gz$gwx_10(){
if( __WXML_GLOBAL__.ops_cached.$gwx_10)return __WXML_GLOBAL__.ops_cached.$gwx_10
__WXML_GLOBAL__.ops_cached.$gwx_10=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_10);return __WXML_GLOBAL__.ops_cached.$gwx_10
}
function gz$gwx_11(){
if( __WXML_GLOBAL__.ops_cached.$gwx_11)return __WXML_GLOBAL__.ops_cached.$gwx_11
__WXML_GLOBAL__.ops_cached.$gwx_11=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[2,'&&'],[[6],[[7],[3,'tencentADList']],[1,4]],[[6],[[6],[[7],[3,'tencentADList']],[1,4]],[3,'openFlag']]])
})(__WXML_GLOBAL__.ops_cached.$gwx_11);return __WXML_GLOBAL__.ops_cached.$gwx_11
}
function gz$gwx_12(){
if( __WXML_GLOBAL__.ops_cached.$gwx_12)return __WXML_GLOBAL__.ops_cached.$gwx_12
__WXML_GLOBAL__.ops_cached.$gwx_12=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_12);return __WXML_GLOBAL__.ops_cached.$gwx_12
}
function gz$gwx_13(){
if( __WXML_GLOBAL__.ops_cached.$gwx_13)return __WXML_GLOBAL__.ops_cached.$gwx_13
__WXML_GLOBAL__.ops_cached.$gwx_13=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[2,'&&'],[[7],[3,'isShowTask']],[[6],[[7],[3,'taskObj']],[3,'taskReward']]])
})(__WXML_GLOBAL__.ops_cached.$gwx_13);return __WXML_GLOBAL__.ops_cached.$gwx_13
}
__WXML_GLOBAL__.ops_set.$gwx=z;
__WXML_GLOBAL__.ops_init.$gwx=true;
var nv_require=function(){var nnm={};var nom={};return function(n){return function(){if(!nnm[n]) return undefined;try{if(!nom[n])nom[n]=nnm[n]();return nom[n];}catch(e){e.message=e.message.replace(/nv_/g,'');var tmp = e.stack.substring(0,e.stack.lastIndexOf(n));e.stack = tmp.substring(0,tmp.lastIndexOf('\n'));e.stack = e.stack.replace(/\snv_/g,' ');e.stack = $gstack(e.stack);e.stack += '\n    at ' + n.substring(2);console.error(e);}
}}}()
var x=['./pages/about/about.wxml','./pages/calorie/calorie.wxml','./pages/complaint/complaint.wxml','./pages/history-red/history.wxml','./pages/index/index.wxml','./pages/invite-reward/reward.wxml','./pages/match/match.wxml','./pages/notice/notice.wxml','./pages/personal/personal.wxml','./pages/poster/poster.wxml','./pages/reward/reward.wxml','./pages/rule/rule.wxml','./pages/task-component/task.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_1()
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
d_[x[1]]={}
var m1=function(e,s,r,gg){
var z=gz$gwx_2()
var xC=_n('view')
_rz(z,xC,'class',0,e,s,gg)
var oD=_v()
_(xC,oD)
if(_oz(z,1,e,s,gg)){oD.wxVkey=1
}
var fE=_v()
_(xC,fE)
var cF=function(oH,hG,cI,gg){
var lK=_v()
_(cI,lK)
var aL=function(eN,tM,bO,gg){
var xQ=_v()
_(bO,xQ)
if(_oz(z,8,eN,tM,gg)){xQ.wxVkey=1
}
xQ.wxXCkey=1
return bO
}
lK.wxXCkey=2
_2z(z,6,aL,oH,hG,gg,lK,'details','index','unique')
return cI
}
fE.wxXCkey=2
_2z(z,3,cF,e,s,gg,fE,'titleItems','index','*this')
oD.wxXCkey=1
_(r,xC)
return r
}
e_[x[1]]={f:m1,j:[],i:[],ti:[],ic:[]}
d_[x[2]]={}
var m2=function(e,s,r,gg){
var z=gz$gwx_3()
return r
}
e_[x[2]]={f:m2,j:[],i:[],ti:[],ic:[]}
d_[x[3]]={}
var m3=function(e,s,r,gg){
var z=gz$gwx_4()
var cT=_v()
_(r,cT)
if(_oz(z,0,e,s,gg)){cT.wxVkey=1
}
cT.wxXCkey=1
return r
}
e_[x[3]]={f:m3,j:[],i:[],ti:[],ic:[]}
d_[x[4]]={}
var m4=function(e,s,r,gg){
var z=gz$gwx_5()
var oV=_n('view')
_rz(z,oV,'class',0,e,s,gg)
var o4=_mz(z,'view',['bindtap',1,'class',1],[],e,s,gg)
var x5=_v()
_(o4,x5)
if(_oz(z,3,e,s,gg)){x5.wxVkey=1
}
x5.wxXCkey=1
_(oV,o4)
var o6=_n('notice')
_rz(z,o6,'class',4,e,s,gg)
_(oV,o6)
var cW=_v()
_(oV,cW)
if(_oz(z,5,e,s,gg)){cW.wxVkey=1
var f7=_mz(z,'view',['bindtap',6,'class',1,'data-type',2],[],e,s,gg)
var c8=_v()
_(f7,c8)
if(_oz(z,9,e,s,gg)){c8.wxVkey=1
}
c8.wxXCkey=1
_(cW,f7)
}
var oX=_v()
_(oV,oX)
if(_oz(z,10,e,s,gg)){oX.wxVkey=1
}
var lY=_v()
_(oV,lY)
if(_oz(z,11,e,s,gg)){lY.wxVkey=1
}
var aZ=_v()
_(oV,aZ)
if(_oz(z,12,e,s,gg)){aZ.wxVkey=1
var h9=_mz(z,'view',['bindtap',13,'class',1,'data-rid',2,'data-type',3],[],e,s,gg)
var o0=_v()
_(h9,o0)
if(_oz(z,17,e,s,gg)){o0.wxVkey=1
}
var cAB=_v()
_(h9,cAB)
if(_oz(z,18,e,s,gg)){cAB.wxVkey=1
}
o0.wxXCkey=1
cAB.wxXCkey=1
_(aZ,h9)
}
var oBB=_mz(z,'view',['bindtap',19,'class',1],[],e,s,gg)
var lCB=_v()
_(oBB,lCB)
if(_oz(z,21,e,s,gg)){lCB.wxVkey=1
}
lCB.wxXCkey=1
_(oV,oBB)
var t1=_v()
_(oV,t1)
if(_oz(z,22,e,s,gg)){t1.wxVkey=1
}
var e2=_v()
_(oV,e2)
if(_oz(z,23,e,s,gg)){e2.wxVkey=1
var aDB=_mz(z,'task',['class',24,'taskObj',1],[],e,s,gg)
_(e2,aDB)
}
var b3=_v()
_(oV,b3)
if(_oz(z,26,e,s,gg)){b3.wxVkey=1
}
cW.wxXCkey=1
oX.wxXCkey=1
lY.wxXCkey=1
aZ.wxXCkey=1
t1.wxXCkey=1
e2.wxXCkey=1
e2.wxXCkey=3
b3.wxXCkey=1
_(r,oV)
var tEB=_mz(z,'view',['catchtouchmove',27,'class',1,'hidden',2],[],e,s,gg)
var eFB=_v()
_(tEB,eFB)
if(_oz(z,30,e,s,gg)){eFB.wxVkey=1
}
eFB.wxXCkey=1
_(r,tEB)
var bGB=_mz(z,'view',['catchtouchmove',31,'class',1,'hidden',2],[],e,s,gg)
var oHB=_v()
_(bGB,oHB)
if(_oz(z,34,e,s,gg)){oHB.wxVkey=1
}
oHB.wxXCkey=1
_(r,bGB)
var xIB=_mz(z,'view',['catchtouchmove',35,'class',1,'hidden',2],[],e,s,gg)
var oJB=_v()
_(xIB,oJB)
if(_oz(z,38,e,s,gg)){oJB.wxVkey=1
}
oJB.wxXCkey=1
_(r,xIB)
var fKB=_mz(z,'view',['catchtouchmove',39,'class',1,'hidden',2],[],e,s,gg)
var cLB=_v()
_(fKB,cLB)
if(_oz(z,42,e,s,gg)){cLB.wxVkey=1
}
cLB.wxXCkey=1
_(r,fKB)
var hMB=_mz(z,'view',['catchtouchmove',43,'class',1,'hidden',2],[],e,s,gg)
var oNB=_v()
_(hMB,oNB)
if(_oz(z,46,e,s,gg)){oNB.wxVkey=1
}
oNB.wxXCkey=1
_(r,hMB)
var cOB=_mz(z,'view',['catchtouchmove',47,'class',1,'hidden',2],[],e,s,gg)
var oPB=_v()
_(cOB,oPB)
if(_oz(z,50,e,s,gg)){oPB.wxVkey=1
}
oPB.wxXCkey=1
_(r,cOB)
var lQB=_mz(z,'view',['catchtouchmove',51,'class',1,'hidden',2],[],e,s,gg)
var aRB=_v()
_(lQB,aRB)
if(_oz(z,54,e,s,gg)){aRB.wxVkey=1
}
aRB.wxXCkey=1
_(r,lQB)
return r
}
e_[x[4]]={f:m4,j:[],i:[],ti:[],ic:[]}
d_[x[5]]={}
var m5=function(e,s,r,gg){
var z=gz$gwx_6()
var eTB=_mz(z,'form',['bindsubmit',0,'reportSubmit',1],[],e,s,gg)
var bUB=_v()
_(eTB,bUB)
if(_oz(z,2,e,s,gg)){bUB.wxVkey=1
}
bUB.wxXCkey=1
_(r,eTB)
var oVB=_mz(z,'view',['catchtouchmove',3,'class',1,'hidden',2],[],e,s,gg)
var xWB=_v()
_(oVB,xWB)
if(_oz(z,6,e,s,gg)){xWB.wxVkey=1
}
xWB.wxXCkey=1
_(r,oVB)
return r
}
e_[x[5]]={f:m5,j:[],i:[],ti:[],ic:[]}
d_[x[6]]={}
var m6=function(e,s,r,gg){
var z=gz$gwx_7()
var fYB=_n('view')
_rz(z,fYB,'class',0,e,s,gg)
var cZB=_v()
_(fYB,cZB)
if(_oz(z,1,e,s,gg)){cZB.wxVkey=1
}
var h1B=_v()
_(fYB,h1B)
if(_oz(z,2,e,s,gg)){h1B.wxVkey=1
}
cZB.wxXCkey=1
h1B.wxXCkey=1
_(r,fYB)
return r
}
e_[x[6]]={f:m6,j:[],i:[],ti:[],ic:[]}
d_[x[7]]={}
var m7=function(e,s,r,gg){
var z=gz$gwx_8()
return r
}
e_[x[7]]={f:m7,j:[],i:[],ti:[],ic:[]}
d_[x[8]]={}
var m8=function(e,s,r,gg){
var z=gz$gwx_9()
var o4B=_v()
_(r,o4B)
if(_oz(z,0,e,s,gg)){o4B.wxVkey=1
}
var l5B=_mz(z,'view',['class',1,'hidden',1],[],e,s,gg)
var a6B=_v()
_(l5B,a6B)
if(_oz(z,3,e,s,gg)){a6B.wxVkey=1
var t7B=_v()
_(a6B,t7B)
if(_oz(z,4,e,s,gg)){t7B.wxVkey=1
}
t7B.wxXCkey=1
}
else{a6B.wxVkey=2
var e8B=_v()
_(a6B,e8B)
if(_oz(z,5,e,s,gg)){e8B.wxVkey=1
}
e8B.wxXCkey=1
}
a6B.wxXCkey=1
_(r,l5B)
o4B.wxXCkey=1
return r
}
e_[x[8]]={f:m8,j:[],i:[],ti:[],ic:[]}
d_[x[9]]={}
var m9=function(e,s,r,gg){
var z=gz$gwx_10()
return r
}
e_[x[9]]={f:m9,j:[],i:[],ti:[],ic:[]}
d_[x[10]]={}
var m10=function(e,s,r,gg){
var z=gz$gwx_11()
var xAC=_v()
_(r,xAC)
if(_oz(z,0,e,s,gg)){xAC.wxVkey=1
}
xAC.wxXCkey=1
return r
}
e_[x[10]]={f:m10,j:[],i:[],ti:[],ic:[]}
d_[x[11]]={}
var m11=function(e,s,r,gg){
var z=gz$gwx_12()
return r
}
e_[x[11]]={f:m11,j:[],i:[],ti:[],ic:[]}
d_[x[12]]={}
var m12=function(e,s,r,gg){
var z=gz$gwx_13()
var cDC=_v()
_(r,cDC)
if(_oz(z,0,e,s,gg)){cDC.wxVkey=1
}
cDC.wxXCkey=1
return r
}
e_[x[12]]={f:m12,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
return root;
}
}
}
	__wxAppCode__['pages/index/index.json'] = {"enablePullDownRefresh":true,"usingComponents":{"notice":"/pages/notice/notice","task":"/pages/task-component/task"}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/index/index.wxml'] = [$gwx, './pages/index/index.wxml'];else __wxAppCode__['pages/index/index.wxml'] = $gwx( './pages/index/index.wxml' );
		__wxAppCode__['pages/notice/notice.json'] = {"component":true,"usingComponents":{}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/notice/notice.wxml'] = [$gwx, './pages/notice/notice.wxml'];else __wxAppCode__['pages/notice/notice.wxml'] = $gwx( './pages/notice/notice.wxml' );
		__wxAppCode__['pages/task-component/task.json'] = {"component":true,"usingComponents":{}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/task-component/task.wxml'] = [$gwx, './pages/task-component/task.wxml'];else __wxAppCode__['pages/task-component/task.wxml'] = $gwx( './pages/task-component/task.wxml' );
	
	define("network/httpDefine.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";module.exports={HTTP_REQUEST_URL:"https://penguinstep.wxgxxc.cn/penguinStep/penguinStepData/getPenguinStep.do",CLIENT_KEY:"glory_step12345!@#$%",CLIENT_VERSION:"1.0.0",CMD_USER_LOGIN_REQ:100,CMD_GET_STEP_CONFIG:101,CMD_GET_NOTICE_LIST:102,CMD_GET_REFERRAL_LIST:103,CMD_GET_REWARD_REQ:104,CMD_TAKE_CASH:105,CMD_GET_CALORIE_DETAILS:106,CMD_GET_MY_STEPS:107,CMD_WECHAT_AD_LIST:108,CMD_GET_TASK_LIST:109,CMD_USER_COMPLAINT:110,CMD_FINISH_TASK:111,CMD_GET_FLOAD_LIST:112,CMD_CLICK_FLOAD_TASK:113,CMD_GET_SHARE_IMG:114,CMD_GET_JUMP_INFO:115,CMD_APP_JUMP_REPORT:116,CMD_GET_REWARD_RED_LIST:117,CMD_OPEN_INVITE_RED:118,CMD_GET_HISTORY_RED_LIST:119,CMD_SAVE_SUBMIT_ID:120,CMD_MATCH_INFO_DATA:121,CMD_TOTAL_PALYER_REWARD:122,CMD_GET_MATCH_REWARD:123,CMD_GET_SYSTEM_INFORMS:124,CMD_GET_NEW_USER_REWARD:125}; 
 			}); 
		define("network/httpRequest.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function e(e,n){return G.log("createHttpRequest 111"),new Promise(function(u,o){G.wxPromisify(wx.request,n)({url:h.HTTP_REQUEST_URL,data:{data:e},header:{"content-type":"application/x-www-form-urlencoded;charset=utf-8"},method:"POST"}).then(function(e){G.log(e);var r=t(e.data);if(null===r){return new Promise(function(e,r){r("返回数据为空")})}return 0!=r.result?new Promise(function(e,n){n(r.reason)}):r.data}).then(function(e){u(e)}).catch(function(e){o(e),r(e)})})}function r(e){G.log(e);var r="网络请求失败，请检查网络连接";e&&"string"==typeof e&&(r=e),wx.showToast({title:r,icon:"none",duration:2e3})}function n(e){var r=JSON.stringify(e);G.log("=====请求数据====="),G.log(r),r=y.utf16to8(r);var n=y.xxtea_encrypt(r,h.CLIENT_KEY);return(new b.Base64).encode(n)}function t(e){t=null;try{var r=(new b.Base64).decode(e),n=y.xxtea_decrypt(r,h.CLIENT_KEY);n=y.utf8to16(n),G.log("=====响应数据====="),G.log(n);var t=JSON.parse(n)}catch(e){G.log(e)}return t}function u(e){var r={command:h.CMD_USER_LOGIN_REQ,version:h.CLIENT_VERSION};return r.data={code:e.code,encryptedData:e.encryptedData,iv:e.iv,referrerId:e.referrerId||"",channelId:e.channelId||"",typeId:e.typeId||"",redEnvelopeId:e.rId||"",scene:e.scene||""},G.log("buildUserLoginData 100"),n(r)}function o(){var e={command:h.CMD_GET_STEP_CONFIG,version:h.CLIENT_VERSION};return e.data={uid:A.userInfo.userId},G.log("buildGetStepConfig 101"),n(e)}function a(){var e={command:h.CMD_GET_NOTICE_LIST,version:h.CLIENT_VERSION};return G.log("buildGetNoticeList 102"),n(e)}function i(){var e={command:h.CMD_GET_REFERRAL_LIST,version:h.CLIENT_VERSION};return e.data={uid:A.userInfo.userId},G.log("buildGetReferralList 103"),n(e)}function d(e){var r={command:h.CMD_GET_REWARD_REQ,version:h.CLIENT_VERSION};return r.data={uid:A.userInfo.userId,redEnvelopeId:e.redEnvelopeId,rewardSeq:e.rewardSeq},G.log("buildGetRewardReq 104"),n(r)}function I(e){var r={command:h.CMD_TAKE_CASH,version:h.CLIENT_VERSION};return r.data={uid:A.userInfo.userId,rewardNum:e.rewardNum},G.log("buildReqTakeCash 105"),n(r)}function s(){var e={command:h.CMD_GET_CALORIE_DETAILS,version:h.CLIENT_VERSION};return e.data={uid:A.userInfo.userId},G.log("buildGetCalorieDetails 106"),n(e)}function c(e){var r={command:h.CMD_GET_MY_STEPS,version:h.CLIENT_VERSION};return r.data={uid:A.userInfo.userId,code:e.code||"",encryptedData:e.encryptedData,iv:e.iv},G.log("buildGetMySteps 107"),n(r)}function f(){var e={command:h.CMD_WECHAT_AD_LIST,version:h.CLIENT_VERSION};return G.log("buildGettWechatAdList 108"),n(e)}function l(){var e={command:h.CMD_GET_TASK_LIST,version:h.CLIENT_VERSION};return e.data={uid:A.userInfo.userId},G.log("buildGetTaskList 109"),n(e)}function _(e){var r={command:h.CMD_USER_COMPLAINT,version:h.CLIENT_VERSION};return r.data={uid:A.userInfo.userId,complaintType:e.complaintType,complaintDes:e.complaintDes},G.log("buildUserComplaint 110"),n(r)}function E(e){var r={command:h.CMD_FINISH_TASK,version:h.CLIENT_VERSION};return r.data={uid:A.userInfo.userId,taskId:e.taskId},G.log("buildFinishTask 110"),n(r)}function m(){var e={command:h.CMD_GET_FLOAD_LIST,version:h.CLIENT_VERSION};return e.data={uid:A.userInfo.userId},G.log("buildGetFloadList 112"),n(e)}function T(e){var r={command:h.CMD_CLICK_FLOAD_TASK,version:h.CLIENT_VERSION};return r.data={uid:A.userInfo.userId,typeId:e.typeId},e.rid&&(r.data.referrerRedEnvelopeId=e.rid),G.log("buildClickFloadTask 113"),n(r)}function R(e){var r={command:h.CMD_GET_SHARE_IMG,version:h.CLIENT_VERSION};return r.data={imageType:e.imageType},G.log("buildGetShareImg 114"),n(r)}function N(e){var r={command:h.CMD_GET_JUMP_INFO,version:h.CLIENT_VERSION};return r.data={channelId:e},G.log("buildGetJumpInfo 115"),n(r)}function v(e){var r={command:h.CMD_APP_JUMP_REPORT,version:h.CLIENT_VERSION};return r.data={uid:A.userInfo.userId,appId:e.appId},G.log("buildReportAppJump 116"),n(r)}function g(){var e={command:h.CMD_GET_REWARD_RED_LIST,version:h.CLIENT_VERSION};return e.data={uid:A.userInfo.userId},G.log("buildGetRewardRedList 117"),n(e)}function C(e){var r={command:h.CMD_OPEN_INVITE_RED,version:h.CLIENT_VERSION};return r.data={uid:A.userInfo.userId,typeId:e.typeId,redEnvelopeId:e.rId},G.log("buildGetOpenInviteRed 118"),n(r)}function S(){var e={command:h.CMD_GET_HISTORY_RED_LIST,version:h.CLIENT_VERSION};return e.data={uid:A.userInfo.userId},G.log("buildHistoryRedList 119"),n(e)}function L(e){var r={command:h.CMD_SAVE_SUBMIT_ID,version:h.CLIENT_VERSION};return r.data={uid:A.userInfo.userId,formId:e.formId},G.log("buildSaveSubmitId 120"),n(r)}function p(){var e={command:h.CMD_MATCH_INFO_DATA,version:h.CLIENT_VERSION};return e.data={uid:A.userInfo.userId},G.log("buildGetMatchInfo 120"),n(e)}function D(){var e={command:h.CMD_TOTAL_PALYER_REWARD,version:h.CLIENT_VERSION};return G.log("buildUpdateTotalData 122"),n(e)}function O(){var e={command:h.CMD_GET_MATCH_REWARD,version:h.CLIENT_VERSION};return e.data={uid:A.userInfo.userId},G.log("buildGetMatchReward 123"),n(e)}function M(){var e={command:h.CMD_GET_SYSTEM_INFORMS,version:h.CLIENT_VERSION};return G.log("buildGetSystemInforms 124"),n(e)}function w(){var e={command:h.CMD_GET_NEW_USER_REWARD,version:h.CLIENT_VERSION};return e.data={uid:A.userInfo.userId},G.log("buildGetNewUserReward 125"),n(e)}var h=require("./httpDefine.js"),G=require("../utils/util.js"),y=require("../utils/xxtea.js"),A=require("../utils/globalDefine.js"),b=require("../utils/base64.js");require("../utils/md5.js");module.exports={requestWxLogin:function(n){return G.log("requestWxLogin start"),new Promise(function(t,o){G.wxPromisify(wx.login)().then(function(r){var o={};o.code=r.code,o.iv=n.iv,o.encryptedData=n.encryptedData,n.scene&&(o.scene=n.scene),n.referrerId&&(o.referrerId=n.referrerId),n.channelId&&(o.channelId=n.channelId),n.typeId&&(o.typeId=n.typeId),n.rId&&(o.rId=n.rId),e(u(o)).then(function(e){var r={};r.userId=e.uid,r.userName=unescape(e.userName),r.headImg=e.headImg,r.rewardNum=e.rewardNum,r.newUserReward=e.newUserReward,r.newUserRewardAmount=e.newUserRewardAmount,r.isNewUser=e.isNewUser,e.referrerInfo&&(e.referrerInfo.userName=unescape(e.referrerInfo.userName||""),r.referrerInfo=e.referrerInfo),A.setTestFlag(e.testFlag),r.invitedResult=e.invitedResult||6,""!=r.userName&&""!=r.headImage?r.hasInfo=!0:r.hasInfo=!1,A.setUserLoginInfo(r),A.sign=e.token,t(e);var n=getCurrentPages();n&&n.length>0&&n[0].onWxLoginCallBack()})}).catch(function(e){r(e)})})},getStepConfig:function(){return e(o(),2)},getNoticeList:function(){return e(a(),2)},getReferralList:function(){return e(i())},getRewardReq:function(r){return e(d(r))},reqTakeCash:function(r){return e(I(r))},getCalorieDetails:function(){return e(s())},getMySteps:function(r){return e(c(r),2)},getWechatAdList:function(){return e(f(),2)},getTaskList:function(){return e(l())},userComplaint:function(r){return e(_(r))},finishTask:function(r){return e(E(r))},getFloadList:function(){return e(m())},clickFloadTask:function(r){return e(T(r))},getShareImg:function(r){return e(R(r))},getJumpInfo:function(r){return e(N(r))},reportAppJump:function(r){return e(v(r))},getRewardRedList:function(){return e(g())},getOpenInviteRed:function(r){return e(C(r))},getHistoryRedList:function(){return e(S())},saveSubmitId:function(r){return e(L(r))},getMatchInfo:function(){return e(p())},updateTotalData:function(){return e(D(),2)},getMatchReward:function(){return e(O())},getSystemInforms:function(){return e(M())},getNewUserReward:function(){return e(w())}}; 
 			}); 
		define("network/httpResponse.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict"; 
 			}); 
		define("utils/aes.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var t=t||function(t,e){var r={},i=r.lib={},n=function(){},s=i.Base={extend:function(t){n.prototype=this;var e=new n;return t&&e.mixIn(t),e.hasOwnProperty("init")||(e.init=function(){e.$super.init.apply(this,arguments)}),e.init.prototype=e,e.$super=this,e},create:function(){var t=this.extend();return t.init.apply(t,arguments),t},init:function(){},mixIn:function(t){for(var e in t)t.hasOwnProperty(e)&&(this[e]=t[e]);t.hasOwnProperty("toString")&&(this.toString=t.toString)},clone:function(){return this.init.prototype.extend(this)}},o=i.WordArray=s.extend({init:function(t,e){t=this.words=t||[],this.sigBytes=void 0!=e?e:4*t.length},toString:function(t){return(t||a).stringify(this)},concat:function(t){var e=this.words,r=t.words,i=this.sigBytes;if(t=t.sigBytes,this.clamp(),i%4)for(var n=0;n<t;n++)e[i+n>>>2]|=(r[n>>>2]>>>24-n%4*8&255)<<24-(i+n)%4*8;else if(65535<r.length)for(n=0;n<t;n+=4)e[i+n>>>2]=r[n>>>2];else e.push.apply(e,r);return this.sigBytes+=t,this},clamp:function(){var e=this.words,r=this.sigBytes;e[r>>>2]&=4294967295<<32-r%4*8,e.length=t.ceil(r/4)},clone:function(){var t=s.clone.call(this);return t.words=this.words.slice(0),t},random:function(e){for(var r=[],i=0;i<e;i+=4)r.push(4294967296*t.random()|0);return new o.init(r,e)}}),c=r.enc={},a=c.Hex={stringify:function(t){var e=t.words;t=t.sigBytes;for(var r=[],i=0;i<t;i++){var n=e[i>>>2]>>>24-i%4*8&255;r.push((n>>>4).toString(16)),r.push((15&n).toString(16))}return r.join("")},parse:function(t){for(var e=t.length,r=[],i=0;i<e;i+=2)r[i>>>3]|=parseInt(t.substr(i,2),16)<<24-i%8*4;return new o.init(r,e/2)}},f=c.Latin1={stringify:function(t){var e=t.words;t=t.sigBytes;for(var r=[],i=0;i<t;i++)r.push(String.fromCharCode(e[i>>>2]>>>24-i%4*8&255));return r.join("")},parse:function(t){for(var e=t.length,r=[],i=0;i<e;i++)r[i>>>2]|=(255&t.charCodeAt(i))<<24-i%4*8;return new o.init(r,e)}},h=c.Utf8={stringify:function(t){try{return decodeURIComponent(escape(f.stringify(t)))}catch(t){throw Error("Malformed UTF-8 data")}},parse:function(t){return f.parse(unescape(encodeURIComponent(t)))}},u=i.BufferedBlockAlgorithm=s.extend({reset:function(){this._data=new o.init,this._nDataBytes=0},_append:function(t){"string"==typeof t&&(t=h.parse(t)),this._data.concat(t),this._nDataBytes+=t.sigBytes},_process:function(e){var r=this._data,i=r.words,n=r.sigBytes,s=this.blockSize,c=n/(4*s);if(e=(c=e?t.ceil(c):t.max((0|c)-this._minBufferSize,0))*s,n=t.min(4*e,n),e){for(var a=0;a<e;a+=s)this._doProcessBlock(i,a);a=i.splice(0,e),r.sigBytes-=n}return new o.init(a,n)},clone:function(){var t=s.clone.call(this);return t._data=this._data.clone(),t},_minBufferSize:0});i.Hasher=u.extend({cfg:s.extend(),init:function(t){this.cfg=this.cfg.extend(t),this.reset()},reset:function(){u.reset.call(this),this._doReset()},update:function(t){return this._append(t),this._process(),this},finalize:function(t){return t&&this._append(t),this._doFinalize()},blockSize:16,_createHelper:function(t){return function(e,r){return new t.init(r).finalize(e)}},_createHmacHelper:function(t){return function(e,r){return new p.HMAC.init(t,r).finalize(e)}}});var p=r.algo={};return r}(Math);!function(){var e=t,r=e.lib.WordArray;e.enc.Base64={stringify:function(t){var e=t.words,r=t.sigBytes,i=this._map;t.clamp(),t=[];for(var n=0;n<r;n+=3)for(var s=(e[n>>>2]>>>24-n%4*8&255)<<16|(e[n+1>>>2]>>>24-(n+1)%4*8&255)<<8|e[n+2>>>2]>>>24-(n+2)%4*8&255,o=0;4>o&&n+.75*o<r;o++)t.push(i.charAt(s>>>6*(3-o)&63));if(e=i.charAt(64))for(;t.length%4;)t.push(e);return t.join("")},parse:function(t){var e=t.length,i=this._map;(n=i.charAt(64))&&-1!=(n=t.indexOf(n))&&(e=n);for(var n=[],s=0,o=0;o<e;o++)if(o%4){var c=i.indexOf(t.charAt(o-1))<<o%4*2,a=i.indexOf(t.charAt(o))>>>6-o%4*2;n[s>>>2]|=(c|a)<<24-s%4*8,s++}return r.create(n,s)},_map:"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/="}}(),function(e){function r(t,e,r,i,n,s,o){return((t=t+(e&r|~e&i)+n+o)<<s|t>>>32-s)+e}function i(t,e,r,i,n,s,o){return((t=t+(e&i|r&~i)+n+o)<<s|t>>>32-s)+e}function n(t,e,r,i,n,s,o){return((t=t+(e^r^i)+n+o)<<s|t>>>32-s)+e}function s(t,e,r,i,n,s,o){return((t=t+(r^(e|~i))+n+o)<<s|t>>>32-s)+e}for(var o=t,c=(f=o.lib).WordArray,a=f.Hasher,f=o.algo,h=[],u=0;64>u;u++)h[u]=4294967296*e.abs(e.sin(u+1))|0;f=f.MD5=a.extend({_doReset:function(){this._hash=new c.init([1732584193,4023233417,2562383102,271733878])},_doProcessBlock:function(t,e){for(o=0;16>o;o++){a=t[c=e+o];t[c]=16711935&(a<<8|a>>>24)|4278255360&(a<<24|a>>>8)}var o=this._hash.words,c=t[e+0],a=t[e+1],f=t[e+2],u=t[e+3],p=t[e+4],d=t[e+5],l=t[e+6],y=t[e+7],_=t[e+8],v=t[e+9],g=t[e+10],B=t[e+11],x=t[e+12],m=t[e+13],k=t[e+14],S=t[e+15],z=o[0],w=o[1],C=o[2],D=o[3],w=s(w=s(w=s(w=s(w=n(w=n(w=n(w=n(w=i(w=i(w=i(w=i(w=r(w=r(w=r(w=r(w,C=r(C,D=r(D,z=r(z,w,C,D,c,7,h[0]),w,C,a,12,h[1]),z,w,f,17,h[2]),D,z,u,22,h[3]),C=r(C,D=r(D,z=r(z,w,C,D,p,7,h[4]),w,C,d,12,h[5]),z,w,l,17,h[6]),D,z,y,22,h[7]),C=r(C,D=r(D,z=r(z,w,C,D,_,7,h[8]),w,C,v,12,h[9]),z,w,g,17,h[10]),D,z,B,22,h[11]),C=r(C,D=r(D,z=r(z,w,C,D,x,7,h[12]),w,C,m,12,h[13]),z,w,k,17,h[14]),D,z,S,22,h[15]),C=i(C,D=i(D,z=i(z,w,C,D,a,5,h[16]),w,C,l,9,h[17]),z,w,B,14,h[18]),D,z,c,20,h[19]),C=i(C,D=i(D,z=i(z,w,C,D,d,5,h[20]),w,C,g,9,h[21]),z,w,S,14,h[22]),D,z,p,20,h[23]),C=i(C,D=i(D,z=i(z,w,C,D,v,5,h[24]),w,C,k,9,h[25]),z,w,u,14,h[26]),D,z,_,20,h[27]),C=i(C,D=i(D,z=i(z,w,C,D,m,5,h[28]),w,C,f,9,h[29]),z,w,y,14,h[30]),D,z,x,20,h[31]),C=n(C,D=n(D,z=n(z,w,C,D,d,4,h[32]),w,C,_,11,h[33]),z,w,B,16,h[34]),D,z,k,23,h[35]),C=n(C,D=n(D,z=n(z,w,C,D,a,4,h[36]),w,C,p,11,h[37]),z,w,y,16,h[38]),D,z,g,23,h[39]),C=n(C,D=n(D,z=n(z,w,C,D,m,4,h[40]),w,C,c,11,h[41]),z,w,u,16,h[42]),D,z,l,23,h[43]),C=n(C,D=n(D,z=n(z,w,C,D,v,4,h[44]),w,C,x,11,h[45]),z,w,S,16,h[46]),D,z,f,23,h[47]),C=s(C,D=s(D,z=s(z,w,C,D,c,6,h[48]),w,C,y,10,h[49]),z,w,k,15,h[50]),D,z,d,21,h[51]),C=s(C,D=s(D,z=s(z,w,C,D,x,6,h[52]),w,C,u,10,h[53]),z,w,g,15,h[54]),D,z,a,21,h[55]),C=s(C,D=s(D,z=s(z,w,C,D,_,6,h[56]),w,C,S,10,h[57]),z,w,l,15,h[58]),D,z,m,21,h[59]),C=s(C,D=s(D,z=s(z,w,C,D,p,6,h[60]),w,C,B,10,h[61]),z,w,f,15,h[62]),D,z,v,21,h[63]);o[0]=o[0]+z|0,o[1]=o[1]+w|0,o[2]=o[2]+C|0,o[3]=o[3]+D|0},_doFinalize:function(){var t=this._data,r=t.words,i=8*this._nDataBytes,n=8*t.sigBytes;r[n>>>5]|=128<<24-n%32;var s=e.floor(i/4294967296);for(r[15+(n+64>>>9<<4)]=16711935&(s<<8|s>>>24)|4278255360&(s<<24|s>>>8),r[14+(n+64>>>9<<4)]=16711935&(i<<8|i>>>24)|4278255360&(i<<24|i>>>8),t.sigBytes=4*(r.length+1),this._process(),r=(t=this._hash).words,i=0;4>i;i++)n=r[i],r[i]=16711935&(n<<8|n>>>24)|4278255360&(n<<24|n>>>8);return t},clone:function(){var t=a.clone.call(this);return t._hash=this._hash.clone(),t}}),o.MD5=a._createHelper(f),o.HmacMD5=a._createHmacHelper(f)}(Math),function(){var e=t,r=e.lib,i=r.Base,n=r.WordArray,s=(r=e.algo).EvpKDF=i.extend({cfg:i.extend({keySize:4,hasher:r.MD5,iterations:1}),init:function(t){this.cfg=this.cfg.extend(t)},compute:function(t,e){for(var r=(c=this.cfg).hasher.create(),i=n.create(),s=i.words,o=c.keySize,c=c.iterations;s.length<o;){a&&r.update(a);var a=r.update(t).finalize(e);r.reset();for(var f=1;f<c;f++)a=r.finalize(a),r.reset();i.concat(a)}return i.sigBytes=4*o,i}});e.EvpKDF=function(t,e,r){return s.create(r).compute(t,e)}}(),t.lib.Cipher||function(e){var r=(l=t).lib,i=r.Base,n=r.WordArray,s=r.BufferedBlockAlgorithm,o=l.enc.Base64,c=l.algo.EvpKDF,a=r.Cipher=s.extend({cfg:i.extend(),createEncryptor:function(t,e){return this.create(this._ENC_XFORM_MODE,t,e)},createDecryptor:function(t,e){return this.create(this._DEC_XFORM_MODE,t,e)},init:function(t,e,r){this.cfg=this.cfg.extend(r),this._xformMode=t,this._key=e,this.reset()},reset:function(){s.reset.call(this),this._doReset()},process:function(t){return this._append(t),this._process()},finalize:function(t){return t&&this._append(t),this._doFinalize()},keySize:4,ivSize:4,_ENC_XFORM_MODE:1,_DEC_XFORM_MODE:2,_createHelper:function(t){return{encrypt:function(e,r,i){return("string"==typeof r?y:d).encrypt(t,e,r,i)},decrypt:function(e,r,i){return("string"==typeof r?y:d).decrypt(t,e,r,i)}}}});r.StreamCipher=a.extend({_doFinalize:function(){return this._process(!0)},blockSize:1});var f=l.mode={},h=function(t,e,r){var i=this._iv;i?this._iv=void 0:i=this._prevBlock;for(var n=0;n<r;n++)t[e+n]^=i[n]},u=(r.BlockCipherMode=i.extend({createEncryptor:function(t,e){return this.Encryptor.create(t,e)},createDecryptor:function(t,e){return this.Decryptor.create(t,e)},init:function(t,e){this._cipher=t,this._iv=e}})).extend();u.Encryptor=u.extend({processBlock:function(t,e){var r=this._cipher,i=r.blockSize;h.call(this,t,e,i),r.encryptBlock(t,e),this._prevBlock=t.slice(e,e+i)}}),u.Decryptor=u.extend({processBlock:function(t,e){var r=this._cipher,i=r.blockSize,n=t.slice(e,e+i);r.decryptBlock(t,e),h.call(this,t,e,i),this._prevBlock=n}}),f=f.CBC=u,u=(l.pad={}).Pkcs7={pad:function(t,e){for(var r=4*e,i=(r=r-t.sigBytes%r)<<24|r<<16|r<<8|r,s=[],o=0;o<r;o+=4)s.push(i);r=n.create(s,r),t.concat(r)},unpad:function(t){t.sigBytes-=255&t.words[t.sigBytes-1>>>2]}},r.BlockCipher=a.extend({cfg:a.cfg.extend({mode:f,padding:u}),reset:function(){a.reset.call(this);var t=(e=this.cfg).iv,e=e.mode;if(this._xformMode==this._ENC_XFORM_MODE)var r=e.createEncryptor;else r=e.createDecryptor,this._minBufferSize=1;this._mode=r.call(e,this,t&&t.words)},_doProcessBlock:function(t,e){this._mode.processBlock(t,e)},_doFinalize:function(){var t=this.cfg.padding;if(this._xformMode==this._ENC_XFORM_MODE){t.pad(this._data,this.blockSize);var e=this._process(!0)}else e=this._process(!0),t.unpad(e);return e},blockSize:4});var p=r.CipherParams=i.extend({init:function(t){this.mixIn(t)},toString:function(t){return(t||this.formatter).stringify(this)}}),f=(l.format={}).OpenSSL={stringify:function(t){var e=t.ciphertext;return((t=t.salt)?n.create([1398893684,1701076831]).concat(t).concat(e):e).toString(o)},parse:function(t){var e=(t=o.parse(t)).words;if(1398893684==e[0]&&1701076831==e[1]){var r=n.create(e.slice(2,4));e.splice(0,4),t.sigBytes-=16}return p.create({ciphertext:t,salt:r})}},d=r.SerializableCipher=i.extend({cfg:i.extend({format:f}),encrypt:function(t,e,r,i){i=this.cfg.extend(i);var n=t.createEncryptor(r,i);return e=n.finalize(e),n=n.cfg,p.create({ciphertext:e,key:r,iv:n.iv,algorithm:t,mode:n.mode,padding:n.padding,blockSize:t.blockSize,formatter:i.format})},decrypt:function(t,e,r,i){return i=this.cfg.extend(i),e=this._parse(e,i.format),t.createDecryptor(r,i).finalize(e.ciphertext)},_parse:function(t,e){return"string"==typeof t?e.parse(t,this):t}}),l=(l.kdf={}).OpenSSL={execute:function(t,e,r,i){return i||(i=n.random(8)),t=c.create({keySize:e+r}).compute(t,i),r=n.create(t.words.slice(e),4*r),t.sigBytes=4*e,p.create({key:t,iv:r,salt:i})}},y=r.PasswordBasedCipher=d.extend({cfg:d.cfg.extend({kdf:l}),encrypt:function(t,e,r,i){return i=this.cfg.extend(i),r=i.kdf.execute(r,t.keySize,t.ivSize),i.iv=r.iv,(t=d.encrypt.call(this,t,e,r.key,i)).mixIn(r),t},decrypt:function(t,e,r,i){return i=this.cfg.extend(i),e=this._parse(e,i.format),r=i.kdf.execute(r,t.keySize,t.ivSize,e.salt),i.iv=r.iv,d.decrypt.call(this,t,e,r.key,i)}})}(),function(){for(var e=t,r=e.lib.BlockCipher,i=e.algo,n=[],s=[],o=[],c=[],a=[],f=[],h=[],u=[],p=[],d=[],l=[],y=0;256>y;y++)l[y]=128>y?y<<1:y<<1^283;for(var _=0,v=0,y=0;256>y;y++){var g=(g=v^v<<1^v<<2^v<<3^v<<4)>>>8^255&g^99;n[_]=g,s[g]=_;var B=l[_],x=l[B],m=l[x],k=257*l[g]^16843008*g;o[_]=k<<24|k>>>8,c[_]=k<<16|k>>>16,a[_]=k<<8|k>>>24,f[_]=k,k=16843009*m^65537*x^257*B^16843008*_,h[g]=k<<24|k>>>8,u[g]=k<<16|k>>>16,p[g]=k<<8|k>>>24,d[g]=k,_?(_=B^l[l[l[m^B]]],v^=l[l[v]]):_=v=1}var S=[0,1,2,4,8,16,32,64,128,27,54],i=i.AES=r.extend({_doReset:function(){for(var t=(r=this._key).words,e=r.sigBytes/4,r=4*((this._nRounds=e+6)+1),i=this._keySchedule=[],s=0;s<r;s++)if(s<e)i[s]=t[s];else{var o=i[s-1];s%e?6<e&&4==s%e&&(o=n[o>>>24]<<24|n[o>>>16&255]<<16|n[o>>>8&255]<<8|n[255&o]):(o=o<<8|o>>>24,o=n[o>>>24]<<24|n[o>>>16&255]<<16|n[o>>>8&255]<<8|n[255&o],o^=S[s/e|0]<<24),i[s]=i[s-e]^o}for(t=this._invKeySchedule=[],e=0;e<r;e++)s=r-e,o=e%4?i[s]:i[s-4],t[e]=4>e||4>=s?o:h[n[o>>>24]]^u[n[o>>>16&255]]^p[n[o>>>8&255]]^d[n[255&o]]},encryptBlock:function(t,e){this._doCryptBlock(t,e,this._keySchedule,o,c,a,f,n)},decryptBlock:function(t,e){var r=t[e+1];t[e+1]=t[e+3],t[e+3]=r,this._doCryptBlock(t,e,this._invKeySchedule,h,u,p,d,s),r=t[e+1],t[e+1]=t[e+3],t[e+3]=r},_doCryptBlock:function(t,e,r,i,n,s,o,c){for(var a=this._nRounds,f=t[e]^r[0],h=t[e+1]^r[1],u=t[e+2]^r[2],p=t[e+3]^r[3],d=4,l=1;l<a;l++)var y=i[f>>>24]^n[h>>>16&255]^s[u>>>8&255]^o[255&p]^r[d++],_=i[h>>>24]^n[u>>>16&255]^s[p>>>8&255]^o[255&f]^r[d++],v=i[u>>>24]^n[p>>>16&255]^s[f>>>8&255]^o[255&h]^r[d++],p=i[p>>>24]^n[f>>>16&255]^s[h>>>8&255]^o[255&u]^r[d++],f=y,h=_,u=v;y=(c[f>>>24]<<24|c[h>>>16&255]<<16|c[u>>>8&255]<<8|c[255&p])^r[d++],_=(c[h>>>24]<<24|c[u>>>16&255]<<16|c[p>>>8&255]<<8|c[255&f])^r[d++],v=(c[u>>>24]<<24|c[p>>>16&255]<<16|c[f>>>8&255]<<8|c[255&h])^r[d++],p=(c[p>>>24]<<24|c[f>>>16&255]<<16|c[h>>>8&255]<<8|c[255&u])^r[d++],t[e]=y,t[e+1]=_,t[e+2]=v,t[e+3]=p},keySize:8});e.AES=r._createHelper(i)}(),module.exports={CryptoJS:t}; 
 			}); 
		define("utils/ald-stat-conf.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";exports.app_key="e643c43b2efe66a831ce8035e21ea8d1",exports.getLocation=!1,exports.plugin=!1; 
 			}); 
		define("utils/ald-stat.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var n="function"==typeof Symbol&&"symbol"==typeof Symbol.iterator?function(n){return typeof n}:function(n){return n&&"function"==typeof Symbol&&n.constructor===Symbol&&n!==Symbol.prototype?"symbol":typeof n};!function(o,t){"object"==("undefined"==typeof exports?"undefined":n(exports))&&"undefined"!=typeof module?module.exports=t():"function"==typeof define&&define.amd?define(t):o.Ald=t()}(void 0,function(){function o(n){this.app=n}function t(n){H=n,this.aldstat=new o(this),S("app","launch")}function e(n){if(H=n,B=n.query.ald_share_src,C=n.query.aldsrc||"",F=n.query.ald_share_src,T=Date.now(),I=Date.now(),!nn){P=""+Date.now()+Math.floor(1e7*Math.random()),O=!1;try{wx.setStorageSync("ald_ifo",!1)}catch(n){}}nn=!1,0!==A&&Date.now()-A>3e5&&(R=""+Date.now()+Math.floor(1e7*Math.random()),I=Date.now()),n.query.ald_share_src&&"1044"==n.scene&&n.shareTicket?wx.getShareInfo({shareTicket:n.shareTicket,success:function(n){J=n,m("event","ald_share_click",JSON.stringify(n))}}):n.query.ald_share_src&&m("event","ald_share_click",1),""===G&&wx.getSetting({withCredentials:!0,success:function(n){n.authSetting["scope.userInfo"]&&wx.getUserInfo({withCredentials:!0,success:function(n){var o=g();G=n,o.ufo=y(n),k=w(n.userInfo.avatarUrl.split("/")),p(o)}})}}),S("app","show")}function a(){A=Date.now(),""===G&&wx.getSetting({success:function(n){n.authSetting["scope.userInfo"]&&wx.getUserInfo({withCredentials:!0,success:function(n){G=n,k=w(n.userInfo.avatarUrl.split("/"));var o=g();o.ufo=y(n),p(o)}})}}),S("app","hide")}function r(n){j++,m("event","ald_error_message",n)}function i(n){Q=n}function s(){W=this.route,X=Date.now(),Z=0,Y=0}function c(){_("page","hide"),z=this.route}function u(){_("page","unload"),z=this.route}function l(){Z++}function f(){Y++}function h(n){var o=v(n.path),t={};for(var e in H.query)"ald_share_src"===e&&(t[e]=H.query[e]);var a="";if(a=-1==n.path.indexOf("?")?n.path+"?":n.path.substr(0,n.path.indexOf("?"))+"?",""!==o)for(var e in o)t[e]=o[e];t.ald_share_src?-1==t.ald_share_src.indexOf(E)&&t.ald_share_src.length<200&&(t.ald_share_src=t.ald_share_src+","+E):t.ald_share_src=E;for(var r in t)-1==r.indexOf("ald")&&(a+=r+"="+t[r]+"&");return n.path=a+"ald_share_src="+t.ald_share_src,m("event","ald_share_status",n),n}function d(){function n(){return Math.floor(65536*(1+Math.random())).toString(16).substring(1)}return n()+n()+n()+n()+n()+n()+n()+n()}function p(n){var o=n,t=0,e=0;!function a(r){e++,r?(n={},n.et=Date.now(),n.at=P,n.uu=E,n.v=b,n.ak=o.ak,n.life=o.life,n.ev=o.ev,n.err="err",n.status=t):(q++,n.at=P,n.et=Date.now(),n.uu=E,n.v=b,n.ak=D.app_key,n.wsr=H,n.oifo=O,n.rq_c=q),wx.request({url:"https://"+M+".aldwx.com/d.html",data:n,header:{AldStat:"MiniApp-Stat",waid:D.appid||"",wst:D.appsecret||"",se:U||"",op:L||"",img:k},method:"GET",success:function(n){t=n.statusCode,200!=n.statusCode&&e<=3&&a("errorsend")},fail:function(){e<=3&&a("errorsend")}})}()}function g(){var n={};for(var o in K)n[o]=K[o];return n}function w(n){for(var o="",t=0;t<n.length;t++)n[t].length>o.length&&(o=n[t]);return o}function y(n){var o={};for(var t in n)"rawData"!=t&&"errMsg"!=t&&(o[t]=n[t]);return o}function v(n){if(-1==n.indexOf("?"))return"";var o={};return n.split("?")[1].split("&").forEach(function(n){var t=n.split("=")[1];o[n.split("=")[0]]=t}),o}function S(n,o){var t=g();t.ev=n,t.life=o,t.ec=j,t.st=N,C&&(t.qr=C,t.sr=C),B&&(t.usr=B),"launch"!==o&&(t.ahs=R),"hide"===o&&(t.hdr=Date.now()-I,t.dr=Date.now()-T,t.ifo=!!O),p(t)}function _(n,o){var t=g();t.ev=n,t.st=Date.now(),t.life=o,t.pp=W,t.pc=z,t.dr=Date.now()-N,t.ndr=Date.now()-X,t.rc=Z,t.bc=Y,t.ahs=R,Q&&"{}"!=JSON.stringify(Q)&&(t.ag=Q),C&&(t.qr=C,t.sr=C),B&&(t.usr=B),V||($=W,V=!0,t.ifp=V,t.fp=W),p(t)}function m(n,o,t){var e=g();e.ev=n,e.tp=o,e.st=N,t&&(e.ct=t),p(e)}function x(n,o,t){if(n[o]){var e=n[o];n[o]=function(n){t.call(this,n,o),e.call(this,n)}}else n[o]=function(n){t.call(this,n,o)}}var D=require("./ald-stat-conf"),b="7.0.0",M="log",P=""+Date.now()+Math.floor(1e7*Math.random()),R=""+Date.now()+Math.floor(1e7*Math.random()),I="",T=0,A=0,U="",L="",k="",q=0,H="",O="",E=function(){var n="";try{n=wx.getStorageSync("aldstat_uuid")}catch(o){n="uuid_getstoragesync"}if(n)O=!1;else{n=d(),O=!0;try{wx.setStorageSync("aldstat_uuid",n),wx.setStorageSync("ald_ifo",!0)}catch(n){wx.setStorageSync("aldstat_uuid","uuid_getstoragesync")}}return n}(),N=Date.now(),B="",C="",F="",j=0,J="",G="",K={},V=!1,W="",z="",Q="",X="",Y=0,Z=0,$="",nn=!0;wx.request({url:"https://"+M+".aldwx.com/config/app.json",header:{AldStat:"MiniApp-Stat"},method:"GET",success:function(n){200===n.statusCode&&(n.data.version!=b&&console.warn("您的SDK不是最新版本，请尽快升级！"),n.data.warn&&console.warn(n.data.warn),n.data.error&&console.error(n.data.error))}});try{var on=wx.getSystemInfoSync();K.br=on.brand,K.pm=on.model,K.pr=on.pixelRatio,K.ww=on.windowWidth,K.wh=on.windowHeight,K.lang=on.language,K.wv=on.version,K.wvv=on.platform,K.wsdk=on.SDKVersion,K.sv=on.system}catch(o){}return wx.getNetworkType({success:function(n){K.nt=n.networkType}}),wx.getSetting({success:function(n){n.authSetting["scope.userLocation"]?wx.getLocation({type:"wgs84",success:function(n){K.lat=n.latitude,K.lng=n.longitude,K.spd=n.speed}}):D.getLocation&&wx.getLocation({type:"wgs84",success:function(n){K.lat=n.latitude,K.lng=n.longitude,K.spd=n.speed}})}}),o.prototype.debug=function(n){m("debug","0",n)},o.prototype.warn=function(n){m("warn","1",n)},o.prototype.sendEvent=function(o,t){if(""!==o&&"string"==typeof o&&o.length<=255)if("string"==typeof t&&t.length<=255)m("event",o,t);else if("object"==(void 0===t?"undefined":n(t))){if(JSON.stringify(t).length>=255)return void console.error("自定义事件参数不能超过255个字符");m("event",o,JSON.stringify(t))}else void 0===t?m("event",o,!1):console.error("事件参数必须为String,Object类型,且参数长度不能超过255个字符");else console.error("事件名称必须为String类型且不能超过255个字符")},o.prototype.sendSession=function(n){if(""!==n&&n)if(""!==D.appid&&""!==D.appsecret){U=n;var o=g();o.st=Date.now(),o.tp="session",o.ct="session",o.ev="event",""===G?wx.getSetting({success:function(n){n.authSetting["scope.userInfo"]?wx.getUserInfo({success:function(n){o.ufo=y(n),k=w(n.userInfo.avatarUrl.split("/")),""!==J&&(o.gid=J),p(o)}}):""!==J?(o.gid=J,p(o)):console.warn("用户未授权")}}):(o.ufo=G,""!==J&&(o.gid=J),p(o))}else console.error("请在配置文件中填写小程序的appid和appsecret！");else console.error("请传入从后台获取的session_key")},o.prototype.sendOpenid=function(n){if(""!==n&&n){L=n;var o=g();o.st=Date.now(),o.tp="openid",o.ev="event",o.ct="openid",p(o)}else console.error("openID不能为空")},D.plugin?{App:function(n){var o={};for(var i in n)"onLaunch"!==i&&"onShow"!==i&&"onHide"!==i&&"onError"!==i&&"onPageNotFound"!==i&&"onUnlaunch"!==i&&(o[i]=n[i]);o.onLaunch=function(o){t.call(this,o),"function"==typeof n.onLaunch&&n.onLaunch.call(this,o)},o.onShow=function(o){e.call(this,o),n.onShow&&"function"==typeof n.onShow&&n.onShow.call(this,o)},o.onHide=function(){a.call(this),n.onHide&&"function"==typeof n.onHide&&n.onHide.call(this)},o.onError=function(o){r.call(this,o),n.onError&&"function"==typeof n.onError&&n.onError.call(this,o)},o.onUnlaunch=function(){n.onUnlaunch&&"function"==typeof n.onUnlaunch&&n.onUnlaunch.call(this)},o.onPageNotFound=function(o){n.onPageNotFound&&"function"==typeof n.onPageNotFound&&n.onPageNotFound.call(this,o)},App(o)},Page:function(n){var o={};for(var t in n)"onLoad"!==t&&"onReady"!==t&&"onShow"!==t&&"onHide"!==t&&"onUnload"!==t&&"onPullDownRefresh"!==t&&"onReachBottom"!==t&&"onShareAppMessage"!==t&&"onPageScroll"!==t&&"onTabItemTap"!==t&&(o[t]=n[t]);o.onLoad=function(o){i.call(this,o),"function"==typeof n.onLoad&&n.onLoad.call(this,o)},o.onShow=function(o){s.call(this),"function"==typeof n.onShow&&n.onShow.call(this,o)},o.onHide=function(o){c.call(this),"function"==typeof n.onHide&&n.onHide.call(this,o)},o.onUnload=function(o){u.call(this),"function"==typeof n.onUnload&&n.onUnload.call(this,o)},o.onReady=function(o){n.onReady&&"function"==typeof n.onReady&&n.onReady.call(this,o)},o.onReachBottom=function(o){f(),n.onReachBottom&&"function"==typeof n.onReachBottom&&n.onReachBottom.call(this,o)},o.onPullDownRefresh=function(o){l(),n.onPullDownRefresh&&"function"==typeof n.onPullDownRefresh&&n.onPullDownRefresh.call(this,o)},o.onPageScroll=function(o){n.onPageScroll&&"function"==typeof n.onPageScroll&&n.onPageScroll.call(this,o)},o.onTabItemTap=function(o){n.onTabItemTap&&"function"==typeof n.onTabItemTap&&n.onTabItemTap.call(this,o)},n.onShareAppMessage&&"function"==typeof n.onShareAppMessage&&(o.onShareAppMessage=function(o){var t=n.onShareAppMessage.call(this,o);return void 0===t?(t={},t.path=this.route):void 0===t.path&&(t.path=this.route),h.call(this,t)}),Page(o)}}:void function(){var n=App,o=Page;App=function(o){x(o,"onLaunch",t),x(o,"onShow",e),x(o,"onHide",a),x(o,"onError",r),n(o)},Page=function(n){var t=n.onShareAppMessage;x(n,"onLoad",i),x(n,"onUnload",u),x(n,"onShow",s),x(n,"onHide",c),x(n,"onReachBottom",f),x(n,"onPullDownRefresh",l),void 0!==t&&null!==t&&(n.onShareAppMessage=function(n){if(void 0!==t){var o=t.call(this,n);return void 0===o?(o={},o.path=this.route):void 0===o.path&&(o.path=this.route),h(o)}}),o(n)}}()}); 
 			}); 
		define("utils/base64.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";module.exports={Base64:function(){var r="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";this.encode=function(o){var e,a,n,h,C,d,c,i="",f=0;for(o=t(o);f<o.length;)h=(e=o.charCodeAt(f++))>>2,C=(3&e)<<4|(a=o.charCodeAt(f++))>>4,d=(15&a)<<2|(n=o.charCodeAt(f++))>>6,c=63&n,isNaN(a)?d=c=64:isNaN(n)&&(c=64),i=i+r.charAt(h)+r.charAt(C)+r.charAt(d)+r.charAt(c);return i},this.decode=function(t){var e,a,n,h,C,d,c="",i=0;for(t=t.replace(/[^A-Za-z0-9\+\/\=]/g,"");i<t.length;)e=r.indexOf(t.charAt(i++))<<2|(h=r.indexOf(t.charAt(i++)))>>4,a=(15&h)<<4|(C=r.indexOf(t.charAt(i++)))>>2,n=(3&C)<<6|(d=r.indexOf(t.charAt(i++))),c+=String.fromCharCode(e),64!=C&&(c+=String.fromCharCode(a)),64!=d&&(c+=String.fromCharCode(n));return c=o(c)};var t=function(r){r=r.replace(/\r\n/g,"\n");for(var t="",o=0;o<r.length;o++){var e=r.charCodeAt(o);e<128?t+=String.fromCharCode(e):e>127&&e<2048?(t+=String.fromCharCode(e>>6|192),t+=String.fromCharCode(63&e|128)):(t+=String.fromCharCode(e>>12|224),t+=String.fromCharCode(e>>6&63|128),t+=String.fromCharCode(63&e|128))}return t},o=function(r){for(var t="",o=0,e=0,a=0,n=0;o<r.length;)(e=r.charCodeAt(o))<128?(t+=String.fromCharCode(e),o++):e>191&&e<224?(a=r.charCodeAt(o+1),t+=String.fromCharCode((31&e)<<6|63&a),o+=2):(a=r.charCodeAt(o+1),n=r.charCodeAt(o+2),t+=String.fromCharCode((15&e)<<12|(63&a)<<6|63&n),o+=3);return t}}}; 
 			}); 
		define("utils/globalDefine.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function e(e){try{for(var r={},t=e.split("?")[1].split("&"),n=0;n<t.length;++n){var a=t[n].split("=");r[a[0]]=a[1]}return r}catch(e){return null}}function r(e){t.userId=e.userId,t.userName=e.userName,t.headImg=e.headImg||"/images/common/default.png",t.hasInfo=e.hasInfo,t.rewardNum=e.rewardNum,t.invitedResult=e.invitedResult,t.newUserReward=e.newUserReward,t.newUserRewardAmount=e.newUserRewardAmount,t.referrerInfo=e.referrerInfo,t.isNewUser=e.isNewUser}var t={},n=1,a={};module.exports={userInfo:t,safetySwitchPage:function(r){if(r){for(var t=getCurrentPages(),n=-1,a=0;a<t.length;++a)if(r.indexOf(t[a].route)>-1){n=a;break}if(n>0){var s=t[n],i=e(r);s.setPageData&&s.setPageData(i);var u=t.length-1-n;wx.navigateBack({delta:u})}else wx.navigateTo({url:r})}},getUserLoginInfo:function(){return t},setUserLoginInfo:function(e){r(e)},splitUrlString:e,setTestFlag:function(e){n=e},getTestFlag:function(){return n},setAdList:function(e){a=e},getAdList:function(){return a}}; 
 			}); 
		define("utils/md5.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function r(r){return h(n(i(r),r.length*A))}function n(r,n){r[n>>5]|=128<<n%32,r[14+(n+64>>>9<<4)]=n;for(var t=1732584193,a=-271733879,i=-1732584194,h=271733878,v=0;v<r.length;v+=16){var A=t,l=a,d=i,g=h;a=c(a=c(a=c(a=c(a=o(a=o(a=o(a=o(a=e(a=e(a=e(a=e(a=u(a=u(a=u(a=u(a,i=u(i,h=u(h,t=u(t,a,i,h,r[v+0],7,-680876936),a,i,r[v+1],12,-389564586),t,a,r[v+2],17,606105819),h,t,r[v+3],22,-1044525330),i=u(i,h=u(h,t=u(t,a,i,h,r[v+4],7,-176418897),a,i,r[v+5],12,1200080426),t,a,r[v+6],17,-1473231341),h,t,r[v+7],22,-45705983),i=u(i,h=u(h,t=u(t,a,i,h,r[v+8],7,1770035416),a,i,r[v+9],12,-1958414417),t,a,r[v+10],17,-42063),h,t,r[v+11],22,-1990404162),i=u(i,h=u(h,t=u(t,a,i,h,r[v+12],7,1804603682),a,i,r[v+13],12,-40341101),t,a,r[v+14],17,-1502002290),h,t,r[v+15],22,1236535329),i=e(i,h=e(h,t=e(t,a,i,h,r[v+1],5,-165796510),a,i,r[v+6],9,-1069501632),t,a,r[v+11],14,643717713),h,t,r[v+0],20,-373897302),i=e(i,h=e(h,t=e(t,a,i,h,r[v+5],5,-701558691),a,i,r[v+10],9,38016083),t,a,r[v+15],14,-660478335),h,t,r[v+4],20,-405537848),i=e(i,h=e(h,t=e(t,a,i,h,r[v+9],5,568446438),a,i,r[v+14],9,-1019803690),t,a,r[v+3],14,-187363961),h,t,r[v+8],20,1163531501),i=e(i,h=e(h,t=e(t,a,i,h,r[v+13],5,-1444681467),a,i,r[v+2],9,-51403784),t,a,r[v+7],14,1735328473),h,t,r[v+12],20,-1926607734),i=o(i,h=o(h,t=o(t,a,i,h,r[v+5],4,-378558),a,i,r[v+8],11,-2022574463),t,a,r[v+11],16,1839030562),h,t,r[v+14],23,-35309556),i=o(i,h=o(h,t=o(t,a,i,h,r[v+1],4,-1530992060),a,i,r[v+4],11,1272893353),t,a,r[v+7],16,-155497632),h,t,r[v+10],23,-1094730640),i=o(i,h=o(h,t=o(t,a,i,h,r[v+13],4,681279174),a,i,r[v+0],11,-358537222),t,a,r[v+3],16,-722521979),h,t,r[v+6],23,76029189),i=o(i,h=o(h,t=o(t,a,i,h,r[v+9],4,-640364487),a,i,r[v+12],11,-421815835),t,a,r[v+15],16,530742520),h,t,r[v+2],23,-995338651),i=c(i,h=c(h,t=c(t,a,i,h,r[v+0],6,-198630844),a,i,r[v+7],10,1126891415),t,a,r[v+14],15,-1416354905),h,t,r[v+5],21,-57434055),i=c(i,h=c(h,t=c(t,a,i,h,r[v+12],6,1700485571),a,i,r[v+3],10,-1894986606),t,a,r[v+10],15,-1051523),h,t,r[v+1],21,-2054922799),i=c(i,h=c(h,t=c(t,a,i,h,r[v+8],6,1873313359),a,i,r[v+15],10,-30611744),t,a,r[v+6],15,-1560198380),h,t,r[v+13],21,1309151649),i=c(i,h=c(h,t=c(t,a,i,h,r[v+4],6,-145523070),a,i,r[v+11],10,-1120210379),t,a,r[v+2],15,718787259),h,t,r[v+9],21,-343485551),t=f(t,A),a=f(a,l),i=f(i,d),h=f(h,g)}return Array(t,a,i,h)}function t(r,n,t,u,e,o){return f(a(f(f(n,r),f(u,o)),e),t)}function u(r,n,u,e,o,c,f){return t(n&u|~n&e,r,n,o,c,f)}function e(r,n,u,e,o,c,f){return t(n&e|u&~e,r,n,o,c,f)}function o(r,n,u,e,o,c,f){return t(n^u^e,r,n,o,c,f)}function c(r,n,u,e,o,c,f){return t(u^(n|~e),r,n,o,c,f)}function f(r,n){var t=(65535&r)+(65535&n);return(r>>16)+(n>>16)+(t>>16)<<16|65535&t}function a(r,n){return r<<n|r>>>32-n}function i(r){for(var n=Array(),t=(1<<A)-1,u=0;u<r.length*A;u+=A)n[u>>5]|=(r.charCodeAt(u/A)&t)<<u%32;return n}function h(r){for(var n=v?"0123456789ABCDEF":"0123456789abcdef",t="",u=0;u<4*r.length;u++)t+=n.charAt(r[u>>2]>>u%4*8+4&15)+n.charAt(r[u>>2]>>u%4*8&15);return t}var v=0,A=8;module.exports={hex_md5:r}; 
 			}); 
		define("utils/sha1.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function r(r){return c(n(o(r),r.length*h))}function n(r,n){r[n>>5]|=128<<24-n%32,r[15+(n+64>>9<<4)]=n;for(var o=Array(80),c=1732584193,f=-271733879,h=-1732584194,i=271733878,v=-1009589776,A=0;A<r.length;A+=16){for(var l=c,g=f,s=h,d=i,y=v,x=0;x<80;x++){o[x]=x<16?r[A+x]:a(o[x-3]^o[x-8]^o[x-14]^o[x-16],1);var C=u(u(a(c,5),t(x,f,h,i)),u(u(v,o[x]),e(x)));v=i,i=h,h=a(f,30),f=c,c=C}c=u(c,l),f=u(f,g),h=u(h,s),i=u(i,d),v=u(v,y)}return Array(c,f,h,i,v)}function t(r,n,t,e){return r<20?n&t|~n&e:r<40?n^t^e:r<60?n&t|n&e|t&e:n^t^e}function e(r){return r<20?1518500249:r<40?1859775393:r<60?-1894007588:-899497514}function u(r,n){var t=(65535&r)+(65535&n);return(r>>16)+(n>>16)+(t>>16)<<16|65535&t}function a(r,n){return r<<n|r>>>32-n}function o(r){for(var n=Array(),t=(1<<h)-1,e=0;e<r.length*h;e+=h)n[e>>5]|=(r.charCodeAt(e/h)&t)<<24-e%32;return n}function c(r){for(var n=f?"0123456789ABCDEF":"0123456789abcdef",t="",e=0;e<4*r.length;e++)t+=n.charAt(r[e>>2]>>8*(3-e%4)+4&15)+n.charAt(r[e>>2]>>8*(3-e%4)&15);return t}var f=0,h=8;module.exports={hex_sha1:r}; 
 			}); 
		define("utils/util.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function t(){wx.showLoading({title:"加载中"})}function e(){wx.hideLoading(),wx.stopPullDownRefresh()}var n=!1,r=function(t){return(t=t.toString())[1]?t:"0"+t};module.exports={formatTime:function(t){var e=t.getFullYear(),n=t.getMonth()+1,o=t.getDate(),i=t.getHours(),a=t.getMinutes(),c=t.getSeconds();return[e,n,o].map(r).join("/")+" "+[i,a,c].map(r).join(":")},formatNumber:r,formatMill:function(t){return t=t.toString(),(t=t.substring(0,2))[1]?t:"0"+t},log:function(t){n&&console.log(t)},error:function(t){n&&console.error(t)},wxPromisify:function(n,r){console.log("wxPromisify 111");var r=r||1;return function(){var o=arguments.length>0&&void 0!==arguments[0]?arguments[0]:{};return new Promise(function(i,a){o.success=function(t){e(),i(t)},o.fail=function(t){e(),a(t)},1===r&&t(),n(o)})}},getSecondsByTimestamp:function(t,e){var n=parseInt(t/1e3).toString(),r=parseInt(t%1e3).toString();if(r.length<3)for(var o=3-r.length,i=0;i<o;++i)r="0"+r;if(e<=3)r=r.substr(0,e);else for(var o=e-r.length,i=0;i<o;++i)r+=Math.floor(10*Math.random());return n+"."+r},timeDelay:function(t){var e=t||[],n=0,r=0;t.length>0&&(n=Math.floor(Math.random()*(t[0].perc-t[t.length-1].perc)+t[t.length-1].perc));for(var o=0;o<e.length;o++)if(n<=e[o].perc){r=parseInt(e[o].timeDelay/e[o].perc*n);break}return r},wxCreateInterstitialAd:function(t,e){var n=null;try{n=wx.getStorageSync("adLimit")||0}catch(t){}var r=(new Date).getTime()-n;if(!n||r>t){var o=(new Date).getTime();try{wx.setStorageSync("adLimit",o)}catch(t){}wx.createInterstitialAd&&wx.createInterstitialAd({adUnitId:e}).show().catch(function(t){return console.log(t.errMsg)})}}}; 
 			}); 
		define("utils/xxtea.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function r(r,t){for(var e=r.length,o=4294967295&r[e-1],n=0;n<e;n++)r[n]=String.fromCharCode(255&r[n],r[n]>>>8&255,r[n]>>>16&255,r[n]>>>24&255);return t?r.join("").substring(0,o):r.join("")}function t(r,t){for(var e=r.length,o=[],n=0;n<e;n+=4)o[n>>2]=r.charCodeAt(n)|r.charCodeAt(n+1)<<8|r.charCodeAt(n+2)<<16|r.charCodeAt(n+3)<<24;return t&&(o[o.length]=e),o}function e(r){var t="",e="",o=0;do{1==(e=r.charCodeAt(o++).toString(16)).length&&(e="0"+e),t+=e}while(o<r.length);return t}function o(r){for(var t="",e=0;e<r.length;){var o=parseInt(r.substr(e,1),16)<<4|parseInt(r.substr(++e,1),16);o&=255,t+=String.fromCharCode(o),++e}return t}module.exports={xxtea_encrypt:function(o,n){if(""==o)return"";for(var a,c,h=t(o,!0),f=t(n,!1),C=h.length-1,i=h[C],u=h[0],s=Math.floor(6+52/(C+1)),d=0;s-- >0;){c=(d=d+2654435769&4294967295)>>>2&3;for(var g=0;g<C;g++)a=(i>>>5^(u=h[g+1])<<2)+(u>>>3^i<<4)^(d^u)+(f[3&g^c]^i),i=h[g]=h[g]+a&4294967295;a=(i>>>5^(u=h[0])<<2)+(u>>>3^i<<4)^(d^u)+(f[3&g^c]^i),i=h[C]=h[C]+a&4294967295}return e(r(h,!1))},xxtea_decrypt:function(e,n){if(""==e)return"";for(var a,c,h=t(e=o(e),!1),f=t(n,!1),C=h.length-1,i=h[C-1],u=h[0],s=2654435769*Math.floor(6+52/(C+1))&4294967295;0!=s;){c=s>>>2&3;for(var d=C;d>0;d--)a=((i=h[d-1])>>>5^u<<2)+(u>>>3^i<<4)^(s^u)+(f[3&d^c]^i),u=h[d]=h[d]-a&4294967295;a=((i=h[C])>>>5^u<<2)+(u>>>3^i<<4)^(s^u)+(f[3&d^c]^i),u=h[0]=h[0]-a&4294967295,s=s-2654435769&4294967295}return r(h,!0)},utf16to8:function(r){var t,e,o,n;for(t="",o=r.length,e=0;e<o;e++)(n=r.charCodeAt(e))>=1&&n<=127?t+=r.charAt(e):n>2047?(t+=String.fromCharCode(224|n>>12&15),t+=String.fromCharCode(128|n>>6&63),t+=String.fromCharCode(128|n>>0&63)):(t+=String.fromCharCode(192|n>>6&31),t+=String.fromCharCode(128|n>>0&63));return t},utf8to16:function(r){var t,e,o,n,a,c;for(t="",o=r.length,e=0;e<o;)switch((n=r.charCodeAt(e++))>>4){case 0:case 1:case 2:case 3:case 4:case 5:case 6:case 7:t+=r.charAt(e-1);break;case 12:case 13:a=r.charCodeAt(e++),t+=String.fromCharCode((31&n)<<6|63&a);break;case 14:a=r.charCodeAt(e++),c=r.charCodeAt(e++),t+=String.fromCharCode((15&n)<<12|(63&a)<<6|(63&c)<<0)}return t}}; 
 			}); 
		define("app.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";require("./utils/ald-stat.js");var e=require("./utils/util.js"),r=require("./network/httpRequest.js");App({onShow:function(a){var t={};if(a.query.channelId){var n=a.query.channelId;e.log("隧道ID："+n),t.channelId=n}if(a.query.scene){var d=decodeURIComponent(a.query.scene);e.log("隧道scene："+d),t.scene=d}if(a.query.referrerId){var o=a.query.referrerId;e.log("邀请人ID："+o),t.referrerId=o}if(a.query.typeId){var u=a.query.typeId;e.log("邀请人红包类型ID："+u),t.typeId=u}if(a.query.rId){var i=a.query.rId;e.log("邀请人红包redEnvelopeId："+i),t.rId=i}t.iv="",t.encryptedData="",r.requestWxLogin(t),this.updateManager()},updateManager:function(){if(wx.canIUse("getUpdateManager")){var r=wx.getUpdateManager();r.onCheckForUpdate(function(r){e.log(r.hasUpdate)}),r.onUpdateReady(function(){wx.showModal({title:"更新提示",content:"新版本已经准备好，是否重启应用？",showCancel:!1,success:function(e){e.confirm&&r.applyUpdate()}})})}},globalData:{}}); 
 			}); 	require("app.js");
 		__wxRoute = 'pages/notice/notice';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'pages/notice/notice.js';	define("pages/notice/notice.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var t=require("../../network/httpRequest.js");require("../../utils/globalDefine.js");Component({properties:{},data:{infoList:[],timer:""},ready:function(){this.getNoticeList()},pageLifetimes:{show:function(){this.clearTimer()},hide:function(){this.clearTimer()}},methods:{clearTimer:function(){var t=this.data.timer;clearInterval(t),this.setData({timer:null})},getNoticeList:function(){var e=this;t.getNoticeList().then(function(t){for(var i=t.msgList||"",s=0;s<i.length;s++){var r=unescape(i[s].userName);r.length>4&&(r=r.substring(0,4)+"...",i[s].userName=r)}e.setData({infoList:i})})}}}); 
 			}); 	require("pages/notice/notice.js");
 		__wxRoute = 'pages/task-component/task';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'pages/task-component/task.js';	define("pages/task-component/task.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";require("../../utils/util.js");var t=require("../../network/httpRequest.js");require("../../utils/globalDefine.js");Component({properties:{taskObj:Object},data:{failModal:!0,taskModal:!0,taskId:"",timeTotal:0,intervalId:null,isShowTask:0},ready:function(){this.isShowTask()},pageLifetimes:{show:function(){var t=this,a=t.data.timeTotal;a>0&&a<30&&(t.stopTimer(),t.setData({timeTotal:0}),wx.showToast({title:"试玩30秒才消失哦",icon:"none",duration:5e3})),this.isShowTask()}},methods:{isShowTask:function(){var t=this,a=wx.getStorageSync("finishTaskTime")||"";a?(new Date).getTime()-a>6e5&&t.setData({isShowTask:1}):t.setData({isShowTask:1})},bindHideFailModal:function(){this.setData({failModal:!0})},bindShowTaskModal:function(){this.setData({taskModal:!1})},bindHideTaskModal:function(){this.setData({taskModal:!0})},bindJumpApp:function(a){var e=this,i=a.currentTarget.dataset.appid,s=a.currentTarget.dataset.appurl,n=a.currentTarget.dataset.type;e.setData({taskId:a.currentTarget.dataset.taskid}),1===n?wx.navigateToMiniProgram({appId:i,path:s,extraData:{foo:"bar"},envVersion:"release",success:function(a){e.startTimer();var s={};s.appId=i,t.reportAppJump(s).then(function(t){})}}):2==n&&wx.previewImage({current:s,urls:[s],success:function(a){e.startTimer();var s={};s.appId=i,t.reportAppJump(s).then(function(t){})}})},finishTask:function(){var a=this,e={};e.taskId=a.data.taskId||"",t.finishTask(e).then(function(t){a.setData({timeTotal:0,isShowTask:0});var e=(new Date).getTime();wx.setStorageSync("finishTaskTime",e)})},startTimer:function(){var t=this;null!=this.data.intervalId&&this.stopTimer();var a="";a=setInterval(function(){var a=t.data.timeTotal;a<30?t.setData({timeTotal:a+1}):(t.finishTask(),t.stopTimer())},1e3),t.setData({intervalId:a})},stopTimer:function(){null!=this.data.intervalId&&clearInterval(this.data.intervalId),this.setData({intervalId:null})}}}); 
 			}); 	require("pages/task-component/task.js");
 		__wxRoute = 'pages/index/index';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'pages/index/index.js';	define("pages/index/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var e=getApp(),t=require("../../utils/util.js"),a=require("../../utils/globalDefine.js"),i=require("../../network/httpRequest.js");Page({data:{hasUserInfo:!1,userInfo:{},stepInfo:{},stepNum:0,ruleModal:!0,invitedResModal:!0,authWeRun:1,referralList:[],stepReward:0,openRedModal:{status:!0},failModal:!0,failTitle:"",tencentADList:[],newUserModal:!0,floadTaskInfo:null,taskObj:{},allTaskObj:{},getStepsModal:!0,isCanVideoAd:!1,jumpModal:0,jumpInfo:{},stepWidth:0,testFlag:1,systemInforms:{},getCount:0,videoRewardModal:!0},timer:"",timeDelay:0,delayConfig:[],videoADSwitch:0,videoAd:{},delayRewardNum:10,bindHideVideoReward:function(){this.setData({videoRewardModal:!0})},bindHideSystemModal:function(){this.setData({systemInforms:0})},bindShowJumpModal:function(){this.setData({jumpModal:1})},bindHideJumpModal:function(){this.setData({jumpModal:0}),this.checkSession(),this.data.userInfo.newUserReward&&this.bindShowNewUser()},bindShowGetSteps:function(){if(4===this.data.authWeRun)this.checkSession();else{this.setData({getStepsModal:!1});this.clickFloadTask("2")}},bindHideGetSteps:function(){var e=this,a=e.timeDelay,i=e.delayRewardNum;e.data.userInfo.rewardNum>i&&a>0?setTimeout(function(){e.setData({getStepsModal:!0}),e.timeDelay=t.timeDelay(e.delayConfig)||0},a):(e.setData({getStepsModal:!0}),e.timeDelay=t.timeDelay(e.delayConfig)||0)},bindShowNewUser:function(){this.data.jumpModal||this.setData({newUserModal:!1})},bindHideNewUser:function(){this.setData({newUserModal:!0})},bindGetNewUserReward:function(){var e=this;i.getNewUserReward().then(function(t){if(t.rewardNum){var i=a.userInfo;i.rewardNum=t.rewardNum,i.newUserReward=0,a.setUserLoginInfo(i),e.setData({userInfo:i,newUserModal:!0}),i.isNewUser&&e.checkSession()}}).catch(function(){e.setData({newUserModal:!0})})},bindShowFailModal:function(e){this.setData({failModal:!1,failTitle:e})},bindHideFailModal:function(){var e=this,a=e.timeDelay,i=e.delayRewardNum;e.data.userInfo.rewardNum>i&&a>0?setTimeout(function(){e.setData({failModal:!0}),e.timeDelay=t.timeDelay(e.delayConfig)||0},a):(e.setData({failModal:!0}),e.timeDelay=t.timeDelay(e.delayConfig)||0)},bindShowRuleModal:function(){this.setData({ruleModal:!1})},bindHideRuleModal:function(){this.setData({ruleModal:!0})},bindShowInvitedRes:function(){this.setData({invitedResModal:!1})},bindHideInvitedRes:function(){var e=this.data.userInfo;e.invitedResult=6,this.setData({invitedResModal:!0,userInfo:e}),a.setUserLoginInfo(e)},bindShowOpenRed:function(e,t,a){this.setData({openRedModal:{status:!1,number:e||.1,text:t||"",type:a||1}})},bindHideOpenRed:function(){var e=this,a=e.timeDelay,i=e.delayRewardNum;e.data.userInfo.rewardNum>i&&a>0?setTimeout(function(){e.setData({openRedModal:{status:!0}}),e.timeDelay=t.timeDelay(e.delayConfig)||0},a):(e.setData({openRedModal:{status:!0}}),e.timeDelay=t.timeDelay(e.delayConfig)||0)},bindGoPersonal:function(){if(4===this.data.authWeRun)this.checkSession();else{wx.switchTab({url:"../personal/personal"})}},bindGoInviteRed:function(){wx.switchTab({url:"../invite-reward/reward"})},bindGoMatch:function(){wx.switchTab({url:"../match/match"})},bindDoTasks:function(e){this.setData({failModal:!0})},bindGoComplaint:function(){a.safetySwitchPage("../complaint/complaint")},bindGoReward:function(e){var t=e.currentTarget.dataset.type;this.remainStamp<0?this.clickFloadTask(t):this.bindShowFailModal("还未到领取时间")},bindGoReward1:function(e){var t=e.currentTarget.dataset.type,a=e.currentTarget.dataset.rid;this.data.floadTaskInfo.pageReward.type1.size>0&&this.clickFloadTask(t,a)},bindPoster:function(){var e="../poster/poster?steps="+this.data.stepNum;a.safetySwitchPage(e)},getUserInfo:function(e){if(e.detail.userInfo){var t={};t.iv=e.detail.iv,t.encryptedData=e.detail.encryptedData,i.requestWxLogin(t),this.setData({newUserModal:!0})}},getWeChatAdList:function(){var e=this;i.getWechatAdList().then(function(i){var n=i.tencentADList||[],s=i.delayConfig||[];a.setAdList(n),e.delayConfig=s,e.timeDelay=t.timeDelay(s)||0,e.delayRewardNum=i.delayRewardNum||10,e.videoADSwitch=i.videoADSwitch||0,e.loadVideoAdObj(),e.setData({tencentADList:n})})},getRewardReq:function(e){var t=this,a=e.currentTarget.dataset.state||0,n=parseInt(e.currentTarget.dataset.status),s=parseInt(e.currentTarget.dataset.type);if(4===t.data.authWeRun)return this.checkSession(),!1;if(a)t.bindShowFailModal("您已领取此红包");else if(n){var o=t.data.stepInfo.redEnvelopeId,r={};r.redEnvelopeId=o,r.rewardSeq=s,i.getRewardReq(r).then(function(e){var a=t.data.stepInfo,n=t.data.userInfo,o="",r="";10===s?(o=a.details[s-1].reward,r="太棒了！您已经领取今日所有红包"):(o=a.details[s-1].reward,r="步数达到"+a.details[s].step+"可累计领"+a.details[s].reward+"能量币"),n.rewardNum=e.rewardNum,t.setData({userInfo:n}),i.getStepConfig().then(function(e){t.setData({stepInfo:e.stepInfo||""})}),t.bindShowOpenRed(o,r)})}else t.bindShowFailModal("步数还不够领取此红包")},onWxLoginCallBack:function(){this.getCurPageData()},getCurPageData:function(){var e=this,t=a.userInfo;null!=t.userId&&void 0!=t.userId&&(e.setData({userInfo:t,hasUserInfo:t.hasInfo,testFlag:a.getTestFlag()}),i.getStepConfig().then(function(t){e.setData({stepInfo:t.stepInfo||""})}),t.hasInfo&&e.checkSession(),e.getReferralList(),1===t.invitedResult&&e.bindShowInvitedRes(),t.newUserReward&&(e.bindShowNewUser(),e.setData({authWeRun:4})),e.getFloadList(),e.getTaskList())},checkSession:function(){var e=this;wx.checkSession({success:function(){e.getUserStepData()},fail:function(){wx.login({success:function(t){t.code?e.getUserStepData(t.code):uitl.log("登录失败！"+t.errMsg)}})}})},getUserStepData:function(e){var t=this;if(t.data.jumpModal)return!1;wx.canIUse("getWeRunData")?wx.getWeRunData({success:function(a){var n={};n.code=e||"",n.encryptedData=a.encryptedData||"",n.iv=a.iv||"",i.getMySteps(n).then(function(e){var a=e.stepNum||0;t.setData({stepNum:a,authWeRun:1}),t.calcWidthFunc(a)}).catch(function(e){})},fail:function(e){wx.getSetting({success:function(e){var a=e.authSetting["scope.werun"];a||void 0==a?(wx.showToast({title:"您手机微信版本过低不支持步数功能",icon:"none",duration:5e3}),t.setData({authWeRun:3})):(t.setData({authWeRun:2}),wx.showToast({title:"未授权微信运动，请点击获取步数授权重试",icon:"none",duration:5e3}))}})}}):(wx.showToast({title:"您手机微信版本过低不支持步数功能",icon:"none",duration:5e3}),t.setData({authWeRun:3}))},getFloadList:function(){var e=this;e.data.userInfo.userId&&i.getFloadList().then(function(t){e.setData({floadTaskInfo:t||null}),e.startRemainTimer()})},clickFloadTask:function(e,t){var n=this,s={};s.typeId=e,t&&(s.rid=t),i.clickFloadTask(s).then(function(t){if(2==e)n.checkSession();else if(1==e){if(t.totalReward){var i=a.userInfo;i.rewardNum=t.totalReward,a.setUserLoginInfo(i),n.setData({userInfo:i})}n.bindShowOpenRed(t.redEnvelopeAmount,"多个好友多条财路")}else if(3==e){if(t.totalReward){var s=a.userInfo;s.rewardNum=t.totalReward,a.setUserLoginInfo(s),n.setData({userInfo:s})}n.bindShowOpenRed(t.redEnvelopeAmount,"每两个小时领一次")}n.getFloadList()})},clickAddSteps:function(){this.clickFloadTask("2"),this.bindHideGetSteps()},bindOpenSetting:function(e){e.detail.authSetting["scope.werun"]&&this.setData({authWeRun:!0})},getReferralList:function(){var e=this;i.getReferralList().then(function(t){var a=t.referralList||[];e.setData({referralList:a,stepReward:t.stepReward||0})}).catch(function(e){})},getShareImg:function(){var e=this,t={};t.imageType=1,i.getShareImg(t).then(function(t){var a=t.redImage||"";e.shareImgDesc=a.imgDesc,e.shareImgUrl=a.imgUrl})},getTaskList:function(){var e=this;e.data.hasUserInfo&&i.getTaskList().then(function(t){for(var a=t.taskRewardList||[],i=[],n=0;n<a.length;n++)a[n].receiveFlag||i.push(a[n]);e.setData({taskObj:i[0]||{},allTaskObj:t||{}})})},getJumpInfo:function(e){var t=this;i.getJumpInfo(e).then(function(e){e&&t.setData({jumpInfo:e.appDesc||{},jumpModal:e.appFlag})})},bindJumpApp:function(e){var t=this,a=e.currentTarget.dataset.appid,n=e.currentTarget.dataset.appurl;wx.navigateToMiniProgram({appId:a,path:n,extraData:{foo:"bar"},envVersion:"release",success:function(e){var n={};n.appId=a,i.reportAppJump(n).then(function(e){t.bindHideJumpModal()})}})},updateRemainTime:function(){var e=this,a=e.remainStamp,i=e.data.floadTaskInfo;if(void 0===a)return!1;if(a<0)return e.stopRemainTimer(),i.remainStamp="可领取",e.setData({floadTaskInfo:i}),!1;var n=parseInt(a/1e3/60/60,10),s=parseInt(a/1e3/60%60,10),o=parseInt(a/1e3%60,10);this.remainStamp=a-1e3,i.remainStamp=t.formatNumber(n)+":"+t.formatNumber(s)+":"+t.formatNumber(o),e.setData({floadTaskInfo:i})},startRemainTimer:function(){var e=this,t=e.data.floadTaskInfo.pageReward.type3;if(t.expireTime){var a=t.expireTime-t.currentTime;e.remainStamp=a}e.stopRemainTimer();var i=setInterval(function(){e.updateRemainTime()},1e3);e.timer=i},stopRemainTimer:function(){var e=this.timer;clearInterval(e)},calcWidthFunc:function(e){for(var t=this,a=t.data.stepInfo.details,i=0,n=0;n<a.length;n++){if(a[n].step>e){var s=0;s=0===n?75*e/a[0].step:80+150*(n-1)+150/(a[n].step-a[n-1].step)*(e-a[n-1].step),t.setData({stepWidth:s});break}a[n].state&&(i+=1)}i>1&&t.setData({getCount:i})},formSubmit:function(e){var a=e.detail.formId;if(t.log("submitId："+a),a.indexOf(" ")<0){var n={};n.formId=a,i.saveSubmitId(n)}},getSystemInforms:function(){var e=this;i.getSystemInforms().then(function(t){if(t){var a=t;e.setData({systemInforms:a}),a.maintenanceNoticeFlag&&!a.closeFlag&&wx.hideTabBar()}})},loadVideoAdObj:function(){var e=this,a=wx.getStorageSync("videoAdLimit")||"",i=e.videoADSwitch,n=1;if(a){var s=a.split("|");t.log(s);var o=t.formatTime(new Date).split(" ")[0],r=s[0],d=parseInt(s[1]);r===o&&d>19&&(n=0,e.setData({isCanVideoAd:!1}))}if(wx.createRewardedVideoAd&&i&&n){var u=wx.createRewardedVideoAd({adUnitId:"adunit-42213a83056e58d9"});e.videoAd=u,u.load().then(function(){e.setData({isCanVideoAd:!0})}).catch(function(t){console.log("loadErr："+t.errMsg),e.setData({isCanVideoAd:!1})}),u.onError(function(t){console.log("onError："+t.errMsg),e.setData({isCanVideoAd:!1})})}},getDoubleReward:function(){var e=this,a=e.videoAd;a.load().then(function(){a.show().then(function(){return t.log("成功调用视频")}).catch(function(e){return t.log(e.errMsg)})}).catch(function(t){console.log("getRewardLoadErr："+t.errMsg),e.setData({isCanVideoAd:!1})}),e.onVideoClose()},onVideoClose:function(){var e=this,a=e.videoAd;a.onClose(function(n){if(a.offClose(),n&&n.isEnded||void 0===n){var s={typeId:4};i.clickFloadTask(s).then(function(){e.checkSession(),e.getFloadList(),e.setData({videoRewardModal:!1,isCanVideoAd:!1});var a=wx.getStorageSync("videoAdLimit")||"",i=t.formatTime(new Date).split(" ")[0],n=1;if(a){var s=a.split("|"),o=s[0],r=parseInt(s[1]);o===i&&(n=r+1)}t.log(i+"|"+n),wx.setStorageSync("videoAdLimit",i+"|"+n)})}else wx.showModal({title:"步数奖励",content:"看完视频后才能获得步数奖励",cancelText:"下次再说",confirmText:"观看视频",success:function(t){t.confirm&&(a.show(),e.onVideoClose())}})})},bindJumpBoutique:function(e){var t=e.currentTarget.dataset.appid,a=e.currentTarget.dataset.appurl,i=e.currentTarget.dataset.type;3===i?wx.navigateToMiniProgram({appId:t,path:a,extraData:{foo:"bar"},envVersion:"release"}):4==i&&wx.previewImage({current:a,urls:[a]})},onLoad:function(t){e.aldstat.sendEvent("用户进入首页");var a=t.channelId||"";this.getJumpInfo(a)},onShow:function(){this.getWeChatAdList(),this.getFloadList(),this.getShareImg(),this.getTaskList(),this.getSystemInforms(),this.setData({userInfo:a.getUserLoginInfo()}),this.setInterstitialAd&&(this.setInterstitialAd=!1,t.wxCreateInterstitialAd(3e4,"adunit-7896c8f6e733eba6"))},onUnload:function(){this.stopRemainTimer()},onHide:function(){this.stopRemainTimer()},bindRefresh:function(){this.getReferralList(),this.checkSession(),this.getFloadList()},onPullDownRefresh:function(){this.setData({ruleModal:!0,invitedResModal:!0,openRedModal:{status:!0},failModal:!0}),this.getReferralList(),this.checkSession(),this.getFloadList()},onShareAppMessage:function(e){var a=this,i=this.data.userInfo.userId||"";return"button"===e.from&&(t.log(e.target),a.setData({failModal:!0})),a.setInterstitialAd=!0,{title:a.shareImgDesc||"步数可换钱，能量币可提现",path:"/pages/index/index?referrerId="+i,imageUrl:a.shareImgUrl||"/images/common/share-cover.png",success:function(e){t.log("--- 转发回调成功 ---")}}}}); 
 			}); 	require("pages/index/index.js");
 		__wxRoute = 'pages/calorie/calorie';__wxRouteBegin = true; 	define("pages/calorie/calorie.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function t(t){if(Array.isArray(t)){for(var e=0,r=Array(t.length);e<t.length;e++)r[e]=t[e];return r}return Array.from(t)}var e=require("../../utils/util.js"),r=(require("../../utils/globalDefine.js"),require("../../network/httpRequest.js"));Page({data:{budgetList:[],listTitle:[],totalList:{}},onWxLoginCallBack:function(){},onLoad:function(){var a=this;r.getCalorieDetails().then(function(r){for(var i=r.rewardList,n=[],o=[],s={},u=0;u<i.length;u++){var l=e.formatTime(new Date(i[u].createDate)),c=l.split(" ")[0];s.hasOwnProperty(c)?s[c]+=i[u].rewardAmount:(s[c]=0,s[c]+=i[u].rewardAmount),s[c]=Math.round(100*s[c])/100,n.push({time:l.split(" ")[1],type:i[u].resourcesDesc,rewardAmount:i[u].rewardAmount,title:c}),o.push(c)}a.setData({budgetList:n,listTitle:[].concat(t(new Set(o))),totalList:s})})},onShareAppMessage:function(t){return"button"===t.from&&e.log(t.target),{title:"步数可换钱，能量币可提现",path:"/pages/index/index",imageUrl:"/images/common/share-cover.png",success:function(t){e.log("--- 转发回调成功 ---")}}}}); 
 			}); 	require("pages/calorie/calorie.js");
 		__wxRoute = 'pages/personal/personal';__wxRouteBegin = true; 	define("pages/personal/personal.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var t=require("../../utils/util.js"),e=require("../../utils/globalDefine.js"),a=require("../../network/httpRequest.js");Page({data:{userInfo:{},takeModal:!0,tencentADList:[],canTakeStatus:!1,getRewardNum:10},bindShowTakeModal:function(){var t=parseInt(this.data.userInfo.rewardNum),e=this.data.canTakeStatus;t>=50&&(e=!0),this.setData({takeModal:!1,canTakeStatus:e})},bindHideTakeModal:function(){this.setData({takeModal:!0})},bindSelectItem:function(t){var e=parseInt(t.currentTarget.dataset.money);this.setData({getRewardNum:e})},bindGetReward:function(){var t=this,n=parseInt(t.data.userInfo.rewardNum),o=t.data.getRewardNum;if(n<50)wx.showModal({title:"提示",content:"总金额未满50元",showCancel:!1});else if(n<75&&50===o)wx.showModal({title:"提示",content:"总金额未满75元",showCancel:!1});else if(n<100&&100===o)wx.showModal({title:"提示",content:"总金额未满100元",showCancel:!1});else{var s={};s.rewardNum=o,a.reqTakeCash(s).then(function(a){var n=t.data.userInfo;n.rewardNum=a.totalReward||0,e.setUserLoginInfo(n),t.setData({userInfo:n}),t.bindHideTakeModal()})}},getWeChatAdList:function(){this.setData({tencentADList:e.getAdList()})},bindGoAbout:function(){e.safetySwitchPage("../about/about")},bindGoCalorie:function(){e.safetySwitchPage("../calorie/calorie")},bindGoMatch:function(){wx.switchTab({url:"../match/match"})},onLoad:function(t){this.getWeChatAdList()},onShow:function(){var t=this,a=e.userInfo;null!=a.userId&&void 0!=a.userId&&t.setData({userInfo:a})},onShareAppMessage:function(e){return"button"===e.from&&t.log(e.target),{title:"步数可换钱，能量币可提现",path:"/pages/index/index",imageUrl:"/images/common/share-cover.png",success:function(e){t.log("--- 转发回调成功 ---")}}}}); 
 			}); 	require("pages/personal/personal.js");
 		__wxRoute = 'pages/complaint/complaint';__wxRouteBegin = true; 	define("pages/complaint/complaint.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var t=require("../../network/httpRequest.js");Page({data:{conditionArr:["界面卡顿","界面错位","不实信息","数据异常","其他异常","意见与建议"],conditionIndex:0,textValue:"",isChoose:!1},onLoad:function(){},bindInputValue:function(t){this.setData({textValue:t.detail.value})},bindChoose:function(t){var n=parseInt(t.currentTarget.dataset.type);this.setData({conditionIndex:n,isChoose:!0})},bindCommit:function(){var n=this,e={};if(e.complaintType=n.data.conditionArr[n.data.conditionIndex],e.complaintDes=n.data.textValue,""===e.complaintDes)return wx.showToast({title:"内容不能为空！",icon:"none",duration:2e3}),!1;t.userComplaint(e).then(function(t){wx.showToast({title:"商家已接受投诉",icon:"none",duration:3e3}),setTimeout(function(){wx.navigateBack({delta:1})},1e3)})}}); 
 			}); 	require("pages/complaint/complaint.js");
 		__wxRoute = 'pages/poster/poster';__wxRouteBegin = true; 	define("pages/poster/poster.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";require("../../utils/util.js");var e=require("../../utils/globalDefine.js");require("../../network/httpRequest.js");Page({data:{writePhotosAlbum:!0},onWxLoginCallBack:function(){},onLoad:function(t){var i=this,s=t.steps||0;wx.showLoading({title:"生成海报中"});var n=e.getUserLoginInfo();wx.getImageInfo({src:n.headImg,complete:function(e){var t=e.path;i.posterCanvas(s,t)}})},posterCanvas:function(t,i){var s=e.getUserLoginInfo(),n=s.userName,o=s.rewardNum+"",a=new Date,l=a.getMonth()+1+"月"+a.getDate()+"日",r="今日运动了"+t+"步",c=wx.createCanvasContext("posterCanvas",this),g=void 0,u=void 0;if(!wx.canIUse("createSelectorQuery"))return wx.showToast({title:"您手机微信版本不支持生成海报功能",icon:"none",duration:5e3}),wx.hideLoading(),!1;var f=wx.createSelectorQuery();f.select("#myPosterView").boundingClientRect(),f.exec(function(e){if(!e[0])return wx.hideLoading(),!1;g=e[0].width,u=e[0].height,c.drawImage("../../images/poster/bg-poster.png",0,0,g,u),c.save(),c.beginPath(),c.arc(45,45,25,0,2*Math.PI,!1),c.clip(),c.drawImage(i,20,20,50,50),c.restore(),c.setTextAlign("left"),c.setFillStyle("#000"),c.setFontSize(18),c.fillText(n,80,50),c.setTextAlign("left"),c.setFillStyle("#000"),c.setFontSize(18),c.fillText(l,30,100),c.setTextAlign("left"),c.setFillStyle("#000"),c.setFontSize(18),c.fillText(r,30,130),c.setTextAlign("left"),c.setFillStyle("#000"),c.setFontSize(18),c.fillText("我已经累计赚了",30,160),c.setTextAlign("left"),c.setFillStyle("#f00"),c.setFontSize(30),c.fillText(o,158,160),c.setTextAlign("left"),c.setFillStyle("#000"),c.setFontSize(18),c.fillText("元",160+14*o.length+5,160);var t=50/525*u;c.drawImage("../../images/poster/qrcode.jpg",g-t-35,u-t-30,t,t),c.draw(),wx.hideLoading()})},export:function(){var e=this;wx.canvasToTempFilePath({canvasId:"posterCanvas",success:function(t){wx.saveImageToPhotosAlbum({filePath:t.tempFilePath,success:function(e){console.log(e)},fail:function(t){wx.getSetting({success:function(t){t.authSetting["scope.writePhotosAlbum"]||e.setData({writePhotosAlbum:!1})}})}})},fail:function(e){console.error(e)}},this)},bindOpenSetting:function(e){e.detail.authSetting["scope.writePhotosAlbum"]&&this.setData({writePhotosAlbum:!0})}}); 
 			}); 	require("pages/poster/poster.js");
 		__wxRoute = 'pages/about/about';__wxRouteBegin = true; 	define("pages/about/about.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";require("../../utils/util.js"),require("../../utils/globalDefine.js"),require("../../network/httpRequest.js");Page({data:{},onWxLoginCallBack:function(){},onLoad:function(){}}); 
 			}); 	require("pages/about/about.js");
 		__wxRoute = 'pages/reward/reward';__wxRouteBegin = true; 	define("pages/reward/reward.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";require("../../utils/util.js");var t=require("../../utils/globalDefine.js"),e=require("../../network/httpRequest.js");Page({data:{userInfo:{},tencentADList:[],redAmount:0,tips1:"恭喜你获得能量币红包",tips3:"邀请好友助力获得更多的步数",tips4:"",btnText:"回到首页邀请好友"},intervalId:null,bindGoIndex:function(t){wx.navigateBack({delta:1})},clickFloadTask:function(n,i){var a=this,s={};s.typeId=n,s.rid=i,e.clickFloadTask(s).then(function(e){a.setData({tips1:"正在努力入账中，请勿退出~",tips3:"邀请好友助力获得更多的步数",tips4:""}),a.startTimer(e.redEnvelopeAmount);var n=t.userInfo;n.rewardNum=e.totalReward||0,t.setUserLoginInfo(n)})},startTimer:function(t){var e=this;null!=e.intervalId&&e.stopTimer();var n=t/50,i="";i=setInterval(function(){var i=parseFloat(e.data.redAmount);i<t?e.setData({redAmount:(i+n).toFixed(4)}):i===t&&e.setData({tips1:"恭喜你获得能量币红包",redAmount:t})},100),e.intervalId=i},stopTimer:function(){null!=this.intervalId&&clearInterval(this.intervalId),this.intervalId=null},onWxLoginCallBack:function(){},onLoad:function(e){var n=this,i=e.typeId||"",a=e.rid||"",s=t.userInfo;n.setData({userInfo:s,tencentADList:t.getAdList()}),i&&!a?n.clickFloadTask(i):a&&n.clickFloadTask(i,a);var r=e.openRedNumber||"",o=e.nextOpenText1||"",l=e.nextOpenText2||"",u=e.btnText||"回到首页邀请好友";r&&n.setData({redAmount:r,tips1:"今日累计获得了",tips3:o,tips4:l,btnText:u})},onHide:function(){this.stopTimer()},onUnload:function(){this.stopTimer()}}); 
 			}); 	require("pages/reward/reward.js");
 		__wxRoute = 'pages/invite-reward/reward';__wxRouteBegin = true; 	define("pages/invite-reward/reward.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function e(e,t,r){return t in e?Object.defineProperty(e,t,{value:r,enumerable:!0,configurable:!0,writable:!0}):e[t]=r,e}var t,r=require("../../utils/util.js"),a=require("../../utils/globalDefine.js"),i=require("../../network/httpRequest.js");Page((t={data:{rewardList:[],currentTime:"",openRedModal:!0,rewardNumber:0},timer:"",bindShowOpenRed:function(){this.setData({openRedModal:!1})},bindHideOpenRed:function(){this.setData({openRedModal:!0})},bindGoRule:function(){a.safetySwitchPage("../rule/rule")},bindGoHistory:function(){a.safetySwitchPage("../history-red/history")},getShareImg:function(){var e=this,t={};t.imageType=1,i.getShareImg(t).then(function(t){var r=t.redImage||"";e.shareImgDesc=r.imgDesc,e.shareImgUrl=r.imgUrl})},getRewardRedList:function(){var e=this;i.getRewardRedList().then(function(t){if(t){var r=t.openRedEnvelopeList||[];e.setData({rewardList:r,currentTime:t.currentTime}),e.startRemainTimer()}})},getInviteReward:function(e){var t=this,r={};r.typeId=e.target.dataset.type,r.rId=e.target.dataset.rid,i.getOpenInviteRed(r).then(function(e){t.bindShowOpenRed(),t.getRewardRedList(),t.setData({rewardNumber:e.referrerReward||0})})},formSubmit:function(e){if(parseInt(e.detail.formId)){r.log("submitId："+e.detail.formId);var t={};t.formId=e.detail.formId,i.saveSubmitId(t)}},updateRemainTime:function(){var e=this,t=e.remainStamp1,a=e.remainStamp2,i=e.remainStamp3;if(t<0||a<0||i<0)return e.stopRemainTimer(),e.getRewardRedList(),!1;var n=parseInt(t/1e3/60/60,10),m=parseInt(t/1e3/60%60,10),s=parseInt(t/1e3%60,10),o=parseInt(a/1e3/60/60,10),d=parseInt(a/1e3/60%60,10),u=parseInt(a/1e3%60,10),f=parseInt(i/1e3/60/60,10),p=parseInt(i/1e3/60%60,10),g=parseInt(i/1e3%60,10);this.remainStamp1=t-1e3,this.remainStamp2=a-1e3,this.remainStamp3=i-1e3;var h=e.data.rewardList;h[0].remainStamp=r.formatNumber(n)+":"+r.formatNumber(m)+":"+r.formatNumber(s),h[1].remainStamp=r.formatNumber(o)+":"+r.formatNumber(d)+":"+r.formatNumber(u),h[2].remainStamp=r.formatNumber(f)+":"+r.formatNumber(p)+":"+r.formatNumber(g),e.setData({rewardList:h})},startRemainTimer:function(){var e=this,t=e.data.rewardList,r=t[0].expireDate-this.data.currentTime,a=t[1].expireDate-this.data.currentTime,i=t[2].expireDate-this.data.currentTime;this.remainStamp1=r,this.remainStamp2=a,this.remainStamp3=i,e.stopRemainTimer();var n=setInterval(function(){e.updateRemainTime()},1e3);e.timer=n},stopRemainTimer:function(){var e=this.timer;clearInterval(e)},onWxLoginCallBack:function(){},onLoad:function(){},onShow:function(){this.getShareImg(),this.getRewardRedList()},onHide:function(){this.stopRemainTimer()},onUnload:function(){this.stopRemainTimer()},onPullDownRefresh:function(){this.getRewardRedList()}},e(t,"getShareImg",function(){var e=this,t={};t.imageType=1,i.getShareImg(t).then(function(t){var r=t.redImage||"";e.shareImgDesc=r.imgDesc,e.shareImgUrl=r.imgUrl})}),e(t,"onShareAppMessage",function(e){var t=this,i=a.getUserLoginInfo().userId||"";if("button"===e.from){r.log(e.target);var n=e.target.dataset.type,m=e.target.dataset.rid;t.setData({openRedModal:!0,failModal:!0})}return{title:t.shareImgDesc||"步数可换钱，卡路里可提现",path:"/pages/index/index?referrerId="+i+"&typeId="+n+"&rId="+m,imageUrl:t.shareImgUrl||"/images/common/share-cover.png",success:function(e){r.log("--- 转发回调成功 ---")}}}),t)); 
 			}); 	require("pages/invite-reward/reward.js");
 		__wxRoute = 'pages/rule/rule';__wxRouteBegin = true; 	define("pages/rule/rule.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";require("../../utils/util.js"),require("../../utils/globalDefine.js"),require("../../network/httpRequest.js");Page({data:{},onWxLoginCallBack:function(){},onLoad:function(){}}); 
 			}); 	require("pages/rule/rule.js");
 		__wxRoute = 'pages/history-red/history';__wxRouteBegin = true; 	define("pages/history-red/history.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var t=require("../../utils/util.js"),e=(require("../../utils/globalDefine.js"),require("../../network/httpRequest.js"));Page({data:{historyList:[]},getHistoryRedList:function(){var i=this;e.getHistoryRedList().then(function(e){for(var s=e.openRedEnvelopeList||[],r=0;r<s.length;r++){var a=t.formatTime(new Date(s[r].createDate));s[r].createDate=a}i.setData({historyList:s})})},onWxLoginCallBack:function(){},onLoad:function(){this.getHistoryRedList()}}); 
 			}); 	require("pages/history-red/history.js");
 		__wxRoute = 'pages/match/match';__wxRouteBegin = true; 	define("pages/match/match.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var t=require("../../utils/util.js"),e=require("../../utils/globalDefine.js"),a=require("../../network/httpRequest.js");Page({data:{ruleModal:!0,matchInfo:{},rankingList:[],rewardArr:[0,0,0,0,0],totalPeople:0,remainStampText:"",openRedModal:!0,rankingReward:0,tencentADList:[]},intervalId:null,bindShowOpenRed:function(){this.setData({openRedModal:!1})},bindHideOpenRed:function(){this.setData({openRedModal:!0})},bindShowRuleModal:function(){this.setData({ruleModal:!1})},bindHideRuleModal:function(){this.setData({ruleModal:!0})},bindGetReward:function(){var t=this,e=t.data.matchInfo;a.getMatchReward().then(function(a){e.myInfo.receivedFlag=1,t.bindShowOpenRed(),t.setData({matchInfo:e,rankingReward:a.rankingReward})})},getMatchInfo:function(){var t=this;a.getMatchInfo().then(function(e){for(var a=e.rankingList||[],n=0;n<a.length;n++)a[n].userName=unescape(a[n].userName||"游客"),a[n].userHeadImg=a[n].userHeadImg||"/images/common/default.png",a[n].totalStep>1e4&&a[n].totalStep<1e8?a[n].totalStep=parseFloat((a[n].totalStep/1e4).toFixed(2))+"万":a[n].totalStep>1e8&&(a[n].totalStep=parseFloat((a[n].totalStep/1e8).toFixed(2))+"亿");e.myInfo&&(e.myInfo.userName=unescape(e.myInfo.userName||"游客"),e.myInfo.userHeadImg=e.myInfo.userHeadImg||"/images/common/default.png",e.myInfo.totalStep>1e4&&e.myInfo.totalStep<1e8?e.myInfo.totalStep=parseFloat((e.myInfo.totalStep/1e4).toFixed(2))+"万":e.myInfo.totalStep>1e8&&(e.myInfo.totalStep=parseFloat((e.myInfo.totalStep/1e8).toFixed(2))+"亿"));var o=(e.totalReward+""||0).split(""),r=5-o.length;if(r>0)for(var i=0;i<r;i++)o.unshift("0");t.setData({matchInfo:e,rankingList:a,rewardArr:o,totalPeople:e.totalPeople}),t.startRemainTimer(e.endDate,e.currentDate)})},getShareImg:function(){var t=this,e={};e.imageType=1,a.getShareImg(e).then(function(e){var a=e.redImage||"";t.shareImgDesc=a.imgDesc,t.shareImgUrl=a.imgUrl})},updateRemainTime:function(){var e=this,a=e.remainStamp;if(a<0){e.stopRemainTimer();var n=e.data.matchInfo;return n.rankingState=2,e.setData({matchInfo:n,remainStampText:"活动已结束，正在结算中~"}),!1}var o=parseInt(a/1e3/60/60/24,10),r=parseInt(a/1e3/60/60%24,10),i=parseInt(a/1e3/60%60,10),s=parseInt(a/1e3%60,10);this.remainStamp=a-1e3;var m="活动结束倒计时："+t.formatNumber(o)+"天"+t.formatNumber(r)+"时"+t.formatNumber(i)+"分"+t.formatNumber(s)+"秒";e.setData({remainStampText:m})},startRemainTimer:function(t,e){var a=this,n=t-e;a.remainStamp=n,a.stopRemainTimer();var o=setInterval(function(){a.updateRemainTime()},1e3);a.intervalId=o},updateTotalData:function(){var t=this;a.updateTotalData().then(function(e){var a=(e.totalReward+""||0).split(""),n=5-a.length;if(n>0)for(var o=0;o<n;o++)a.unshift("0");t.setData({rewardArr:a,totalPeople:e.totalPeople})})},stopRemainTimer:function(){var t=this.intervalId;clearInterval(t)},getWeChatAdList:function(){this.setData({tencentADList:e.getAdList()})},onWxLoginCallBack:function(){},bindRefresh:function(){this.getMatchInfo()},onPullDownRefresh:function(){this.getMatchInfo()},onLoad:function(){this.getWeChatAdList()},onShow:function(){this.getMatchInfo(),this.getShareImg()},onHide:function(){this.stopRemainTimer()},onUnload:function(){this.stopRemainTimer()},onShareAppMessage:function(a){var n=this,o=e.getUserLoginInfo().userId||"";return"button"===a.from&&(t.log(a.target),n.setData({openRedModal:!0,ruleModal:!0})),{title:n.shareImgDesc||"步数可换钱，卡路里可提现",path:"/pages/index/index?referrerId="+o,imageUrl:n.shareImgUrl||"/images/common/share-cover.png",success:function(e){t.log("--- 转发回调成功 ---")}}}}); 
 			}); 	require("pages/match/match.js");
 	